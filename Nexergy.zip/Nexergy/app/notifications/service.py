﻿from .repository import NotificationsRepository
from .providers import EmailProvider, SMSProvider, WhatsAppProvider, PushNotificationProvider
from .constants import CHANNEL_EMAIL, CHANNEL_SMS, CHANNEL_WHATSAPP, CHANNEL_PUSH, STATUS_SENT, STATUS_FAILED

class NotificationsService:
    def __init__(self):
        self.repository = NotificationsRepository()
        self.email_provider = EmailProvider()
        self.sms_provider = SMSProvider()
        self.whatsapp_provider = WhatsAppProvider()
        self.push_provider = PushNotificationProvider()

    def send_notification(self, user_id: int, channel: str, title: str, message: str, recipient: str = None) -> dict:
        # Crear notificación en repositorio
        notification = self.repository.create_notification(user_id, channel, title, message)
        
        try:
            # Enviar según el canal
            if channel == CHANNEL_EMAIL:
                result = self.email_provider.send(recipient or 'user@example.com', title, message)
            elif channel == CHANNEL_SMS:
                result = self.sms_provider.send(recipient or '+1234567890', message)
            elif channel == CHANNEL_WHATSAPP:
                result = self.whatsapp_provider.send(recipient or '+1234567890', message)
            elif channel == CHANNEL_PUSH:
                result = self.push_provider.send(recipient or 'device_id', title, message)
            else:
                result = {'success': False, 'message': 'Canal desconocido'}
            
            # Actualizar estado
            status = STATUS_SENT if result.get('success') else STATUS_FAILED
            self.repository.update_notification(notification['id'], status)
            notification['status'] = status
            
            return {'success': True, 'notification': notification, 'provider_result': result}
        except Exception as e:
            self.repository.update_notification(notification['id'], STATUS_FAILED)
            return {'success': False, 'error': str(e)}

    def get_user_notifications(self, user_id: int):
        return self.repository.get_user_notifications(user_id)

    def get_notification(self, notification_id: int):
        return self.repository.get_notification_by_id(notification_id)

    def mark_as_read(self, notification_id: int):
        return self.repository.update_notification(notification_id, STATUS_SENT)

    def delete_notification(self, notification_id: int):
        return self.repository.delete_notification(notification_id)

﻿from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class NotificationSchema(BaseModel):
    id: int
    user_id: int
    channel: str
    title: str
    message: str
    status: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class NotificationCreateSchema(BaseModel):
    user_id: int
    channel: str
    title: str
    message: str

class NotificationUpdateSchema(BaseModel):
    status: str
    updated_at: Optional[datetime] = None

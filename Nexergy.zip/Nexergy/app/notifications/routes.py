﻿from fastapi import APIRouter, HTTPException
from .service import NotificationsService
from .schemas import NotificationCreateSchema, NotificationSchema
from typing import List

router = APIRouter(prefix="/notifications", tags=["notifications"])
service = NotificationsService()

@router.get("", response_model=List[dict])
def get_notifications(user_id: int):
    notifications = service.get_user_notifications(user_id)
    return notifications

@router.post("", response_model=dict)
def create_notification(notification: NotificationCreateSchema):
    result = service.send_notification(
        user_id=notification.user_id,
        channel=notification.channel,
        title=notification.title,
        message=notification.message
    )
    if not result['success']:
        raise HTTPException(status_code=400, detail=result.get('error', 'Error al crear notificación'))
    return result['notification']

@router.get("/{notification_id}", response_model=dict)
def get_notification(notification_id: int):
    notification = service.get_notification(notification_id)
    if not notification:
        raise HTTPException(status_code=404, detail="Notificación no encontrada")
    return notification

@router.post("/{notification_id}/read")
def mark_as_read(notification_id: int):
    result = service.mark_as_read(notification_id)
    if not result:
        raise HTTPException(status_code=404, detail="Notificación no encontrada")
    return {"status": "read", "notification": result}

@router.delete("/{notification_id}")
def delete_notification(notification_id: int):
    success = service.delete_notification(notification_id)
    if not success:
        raise HTTPException(status_code=404, detail="Notificación no encontrada")
    return {"message": "Notificación eliminada"}

﻿from typing import Optional, List
from datetime import datetime
from .constants import STATUS_PENDING

class NotificationsRepository:
    def __init__(self):
        # Simulación de base de datos en memoria
        self.notifications = {}
        self.counter = 1

    def create_notification(self, user_id: int, channel: str, title: str, message: str) -> dict:
        notification = {
            'id': self.counter,
            'user_id': user_id,
            'channel': channel,
            'title': title,
            'message': message,
            'status': STATUS_PENDING,
            'created_at': datetime.now(),
            'updated_at': None
        }
        self.notifications[self.counter] = notification
        self.counter += 1
        return notification

    def get_notification_by_id(self, notification_id: int) -> Optional[dict]:
        return self.notifications.get(notification_id)

    def get_user_notifications(self, user_id: int) -> List[dict]:
        return [n for n in self.notifications.values() if n['user_id'] == user_id]

    def update_notification(self, notification_id: int, status: str) -> Optional[dict]:
        if notification_id in self.notifications:
            self.notifications[notification_id]['status'] = status
            self.notifications[notification_id]['updated_at'] = datetime.now()
            return self.notifications[notification_id]
        return None

    def delete_notification(self, notification_id: int) -> bool:
        if notification_id in self.notifications:
            del self.notifications[notification_id]
            return True
        return False

﻿from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class ReportSchema(BaseModel):
    id: int
    user_id: int
    type: str
    format: str
    filename: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class ReportCreateSchema(BaseModel):
    user_id: int
    type: str
    format: str

class ReportDownloadSchema(BaseModel):
    report_id: int
    format: str

﻿from flask import Blueprint

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/', methods=['GET'])
def reports_status():
    return {"status": "ok"}

# TODO: Implementar endpoints de reports

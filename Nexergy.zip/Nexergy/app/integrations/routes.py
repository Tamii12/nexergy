﻿from flask import Blueprint

integrations_bp = Blueprint('integrations', __name__)

@integrations_bp.route('/', methods=['GET'])
def integrations_status():
    return {"status": "ok"}

# TODO: Implementar endpoints de integrations

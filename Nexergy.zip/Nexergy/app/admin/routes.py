﻿from flask import Blueprint

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/', methods=['GET'])
def admin_status():
    return {"status": "ok"}

# TODO: Implementar endpoints de admin

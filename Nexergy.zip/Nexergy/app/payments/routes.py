﻿from flask import Blueprint

payments_bp = Blueprint('payments', __name__)

@payments_bp.route('/', methods=['GET'])
def payments_status():
    return {"status": "ok"}

# TODO: Implementar endpoints de payments

﻿from flask import Blueprint

websockets_bp = Blueprint('websockets', __name__)

@websockets_bp.route('/', methods=['GET'])
def websockets_status():
    return {"status": "ok"}

# TODO: Implementar endpoints de websockets

﻿from flask import Blueprint

gamification_bp = Blueprint('gamification', __name__)

@gamification_bp.route('/', methods=['GET'])
def gamification_status():
    return {"status": "ok"}

# TODO: Implementar endpoints de gamification

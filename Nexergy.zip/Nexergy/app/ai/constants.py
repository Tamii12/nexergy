﻿# Constants for AI module

# Providers
PROVIDER_OPENAI = 'openai'
PROVIDER_ANTHROPIC = 'anthropic'
PROVIDER_COHERE = 'cohere'

# Models
MODEL_GPT4 = 'gpt-4'
MODEL_GPT35 = 'gpt-3.5-turbo'

# Limits
MAX_CONVERSATION_LENGTH = 50  # messages
MAX_MESSAGE_LENGTH = 5000  # characters

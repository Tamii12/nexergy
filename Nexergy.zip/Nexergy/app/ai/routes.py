﻿from flask import Blueprint, request, jsonify
from app.ai.service import AIService
from app.ai.schemas import ConversationCreateSchema, ChatMessageSchema, ConversationSchema, MessageSchema

ai_bp = Blueprint('ai', __name__, url_prefix='/api/ai')
ai_service = AIService()

# Schemas for validation
conversation_create_schema = ConversationCreateSchema()
chat_message_schema = ChatMessageSchema()
conversation_schema = ConversationSchema()
message_schema = MessageSchema()

@ai_bp.route('/conversations', methods=['POST'])
def create_conversation():
    """Create a new conversation"""
    try:
        # Validate request data
        data = conversation_create_schema.load(request.get_json())
        
        # Get user_id from request (in a real app, from authentication)
        user_id = request.args.get('user_id', 1, type=int)
        
        # Create conversation
        conversation = ai_service.create_conversation(user_id, data['title'])
        
        return jsonify(conversation_schema.dump(conversation)), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@ai_bp.route('/conversations', methods=['GET'])
def list_conversations():
    """List all conversations for a user"""
    try:
        user_id = request.args.get('user_id', 1, type=int)
        conversations = ai_service.get_user_conversations(user_id)
        return jsonify(conversation_schema.dump(conversations, many=True)), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@ai_bp.route('/conversations/<int:conversation_id>', methods=['GET'])
def get_conversation(conversation_id):
    """Get a specific conversation"""
    try:
        conversation = ai_service.get_conversation(conversation_id)
        if not conversation:
            return jsonify({'error': 'Conversation not found'}), 404
        return jsonify(conversation_schema.dump(conversation)), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@ai_bp.route('/conversations/<int:conversation_id>/messages', methods=['POST'])
def send_message(conversation_id):
    """Send a message to a conversation"""
    try:
        # Validate request data
        data = chat_message_schema.load(request.get_json())
        
        # Add user message
        user_message = ai_service.send_message(conversation_id, data['content'], 'user')
        
        # Generate AI response
        messages = [{'role': 'user', 'content': data['content']}]
        ai_message = ai_service.generate_response(conversation_id, messages)
        
        return jsonify({
            'user_message': message_schema.dump(user_message),
            'ai_message': message_schema.dump(ai_message)
        }), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@ai_bp.route('/conversations/<int:conversation_id>/messages', methods=['GET'])
def get_messages(conversation_id):
    """Get all messages in a conversation"""
    try:
        limit = request.args.get('limit', None, type=int)
        messages = ai_service.repository.get_conversation_messages(conversation_id, limit)
        return jsonify(message_schema.dump(messages, many=True)), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

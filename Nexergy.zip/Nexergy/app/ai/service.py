﻿from app.base.service import BaseService
from app.ai.repository import AIRepository
from app.ai.factory import get_provider
from app.ai import constants

class AIService(BaseService):
    """Service for AI-related operations"""
    
    def __init__(self):
        """Initialize AI service"""
        self.repository = AIRepository()
    
    def create_conversation(self, user_id, title):
        """Create a new conversation
        
        Args:
            user_id (int): ID of the user
            title (str): Title of the conversation
            
        Returns:
            dict: Created conversation data
        """
        return self.repository.create_conversation(user_id, title)
    
    def get_user_conversations(self, user_id):
        """Get all conversations for a user
        
        Args:
            user_id (int): ID of the user
            
        Returns:
            list: List of conversations
        """
        return self.repository.get_user_conversations(user_id)
    
    def get_conversation(self, conversation_id):
        """Get a specific conversation
        
        Args:
            conversation_id (int): ID of the conversation
            
        Returns:
            dict: Conversation data
        """
        return self.repository.get_conversation(conversation_id)
    
    def send_message(self, conversation_id, content, role='user'):
        """Send a message to a conversation
        
        Args:
            conversation_id (int): ID of the conversation
            content (str): Message content
            role (str): Role of the sender (user/assistant)
            
        Returns:
            dict: Created message data
        """
        return self.repository.add_message(conversation_id, role, content)
    
    def generate_response(self, conversation_id, messages, provider_type=constants.PROVIDER_OPENAI, api_key=None):
        """Generate AI response for a conversation
        
        Args:
            conversation_id (int): ID of the conversation
            messages (list): List of message dictionaries
            provider_type (str): Type of AI provider
            api_key (str): API key for the provider
            
        Returns:
            dict: Generated message data
        """
        # Get provider using factory pattern
        provider = get_provider(provider_type, api_key)
        
        # Generate response
        response_text = provider.generate_response(messages)
        
        # Save response to database
        return self.repository.add_message(conversation_id, 'assistant', response_text)

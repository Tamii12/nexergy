﻿from marshmallow import Schema, fields, validate

class ConversationCreateSchema(Schema):
    """Schema for creating a conversation"""
    title = fields.Str(required=True)

class ConversationSchema(Schema):
    """Schema for conversation response"""
    id = fields.Int(dump_only=True)
    user_id = fields.Int(required=True)
    title = fields.Str(required=True)
    created_at = fields.DateTime(dump_only=True)
    updated_at = fields.DateTime(dump_only=True)

class MessageSchema(Schema):
    """Schema for message response"""
    id = fields.Int(dump_only=True)
    conversation_id = fields.Int(required=True)
    role = fields.Str(required=True)
    content = fields.Str(required=True)
    timestamp = fields.DateTime(dump_only=True)

class ChatMessageSchema(Schema):
    """Schema for chat message input"""
    content = fields.Str(required=True)
    role = fields.Str(
        required=True,
        validate=validate.OneOf(['user', 'assistant'])
    )

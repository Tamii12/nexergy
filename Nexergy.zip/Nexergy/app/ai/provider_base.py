﻿from abc import ABC, abstractmethod

class ProviderBase(ABC):
    """Abstract base class for AI providers"""
    
    def __init__(self, api_key):
        """Initialize provider with API key
        
        Args:
            api_key (str): API key for the provider
        """
        self.api_key = api_key
    
    @abstractmethod
    def generate_response(self, messages, context=None):
        """Generate response from messages
        
        Args:
            messages (list): List of message dictionaries with 'role' and 'content'
            context (dict): Optional context for generation
            
        Returns:
            str: Generated response text
        """
        pass

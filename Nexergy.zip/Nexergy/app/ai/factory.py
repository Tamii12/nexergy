﻿from app.ai.provider_base import ProviderBase
from app.ai.openai_provider import OpenAIProvider
from app.ai import constants

class AnthropicProvider(ProviderBase):
    """Anthropic provider implementation (stub)"""
    
    def __init__(self, api_key):
        super().__init__(api_key)
    
    def generate_response(self, messages, context=None):
        if messages:
            last_message = messages[-1].get('content', '')
            return f"Anthropic response to: {last_message[:50]}..."
        return "No messages provided"

class CohereProvider(ProviderBase):
    """Cohere provider implementation (stub)"""
    
    def __init__(self, api_key):
        super().__init__(api_key)
    
    def generate_response(self, messages, context=None):
        if messages:
            last_message = messages[-1].get('content', '')
            return f"Cohere response to: {last_message[:50]}..."
        return "No messages provided"

def get_provider(provider_type, api_key=None):
    """Factory function to get the correct provider instance
    
    Args:
        provider_type (str): Type of provider ('openai', 'anthropic', 'cohere')
        api_key (str): API key for the provider
        
    Returns:
        ProviderBase: Provider instance
        
    Raises:
        ValueError: If provider type is not supported
    """
    if provider_type == constants.PROVIDER_OPENAI:
        return OpenAIProvider(api_key or '')
    elif provider_type == constants.PROVIDER_ANTHROPIC:
        return AnthropicProvider(api_key or '')
    elif provider_type == constants.PROVIDER_COHERE:
        return CohereProvider(api_key or '')
    else:
        raise ValueError(f"Unsupported provider type: {provider_type}")

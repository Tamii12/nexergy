﻿"""AI module for conversation and message management"""

from app.ai.constants import *
from app.ai.service import AIService
from app.ai.factory import get_provider

__all__ = [
    'AIService',
    'get_provider',
    'PROVIDER_OPENAI',
    'PROVIDER_ANTHROPIC',
    'PROVIDER_COHERE',
    'MODEL_GPT4',
    'MODEL_GPT35',
    'MAX_CONVERSATION_LENGTH',
    'MAX_MESSAGE_LENGTH'
]

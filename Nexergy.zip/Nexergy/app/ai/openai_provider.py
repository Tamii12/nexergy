﻿from app.ai.provider_base import ProviderBase

class OpenAIProvider(ProviderBase):
    """OpenAI provider implementation"""
    
    def __init__(self, api_key):
        """Initialize OpenAI provider
        
        Args:
            api_key (str): OpenAI API key
        """
        super().__init__(api_key)
    
    def generate_response(self, messages, context=None):
        """Generate response using OpenAI API (simulated)
        
        Args:
            messages (list): List of message dictionaries
            context (dict): Optional context
            
        Returns:
            str: Simulated generated response
        """
        # Simulated response for basic functionality
        if messages:
            last_message = messages[-1].get('content', '')
            return f"OpenAI response to: {last_message[:50]}..."
        return "No messages provided"

# NEXERGY - Arquitectura Completa del Sistema

## Visión General

Nexergy es un sistema inteligente de monitoreo eléctrico residencial que combina análisis en tiempo real, gestión de dispositivos IoT, recomendaciones de IA y gamificación para optimizar el consumo energético.

### Decisiones Arquitectónicas Clave

**Arquitectura:** Monolito modular listo para escalar  
**Frontend:** HTML/CSS/JS vanilla + librerías ligeras por CDN  
**Backend:** Flask con separación por dominios  
**Base de datos:** MariaDB con SQLAlchemy + Flask-Migrate  
**IA:** Capa abstracta multi-provider preparada para futuro  
**Tiempo Real:** WebSockets (Flask-SocketIO)  

### Diagrama de Arquitectura Lógica

```mermaid
graph TD
    UI[Frontend HTML/CSS/JS] --> API[Flask App]
    API --> AUTH[Auth Module]
    API --> ENERGY[Energy Module]
    API --> DEV[Devices Module]
    API --> ALERTS[Alerts Module]
    API --> PAY[Payments Module]
    API --> AI[AI Provider Abstraction]
    API --> NOTI[Realtime Notifications]
    API --> REP[Reports Module]
    API --> ADMIN[Admin Module]
    API --> GAMIF[Gamification Module]
    AUTH --> DB[(MariaDB)]
    ENERGY --> DB
    DEV --> DB
    ALERTS --> DB
    PAY --> DB
    REP --> DB
    ADMIN --> DB
    GAMIF --> DB
    API --> EXT1[OpenWeatherMap]
    API --> EXT2[Stripe]
    API --> EXT3[SendGrid/Gmail]
    API --> EXT4[Twilio]
    API --> EXT5[OpenAI & Future Providers]
```

---

## Árbol de Archivos Completo

```
Nexergy/
├── .env.example                      # Plantilla de variables de entorno
├── .gitignore                        # Exclusiones de Git
├── README.md                         # Documentación principal del proyecto
├── ARCHITECTURE.md                   # Este documento
├── requirements.txt                  # Dependencias Python
├── run.py                           # Entry point para desarrollo
├── wsgi.py                          # Entry point para producción WSGI
├── asgi.py                          # Entry point para producción ASGI (WebSockets)
├── config.py                        # Configuración global del proyecto
│
├── app/                             # Código backend Flask
│   ├── __init__.py                  # Factory de aplicación Flask
│   ├── extensions.py                # Inicialización de extensiones (db, jwt, bcrypt, socketio, etc.)
│   ├── routes.py                    # Registro de blueprints
│   │
│   ├── core/                        # Núcleo compartido
│   │   ├── __init__.py
│   │   ├── security.py              # Utilidades XSS, CSRF, SQL injection prevention
│   │   ├── validators.py            # Validadores personalizados
│   │   ├── errors.py                # Manejo global de errores y excepciones
│   │   ├── decorators.py            # Decoradores auth/roles/rate-limit
│   │   ├── jwt_helpers.py           # Utilidades JWT (generate, verify, blacklist)
│   │   ├── bcrypt_helpers.py        # Wrappers bcrypt
│   │   ├── base_service.py          # Clase base para servicios
│   │   ├── base_repository.py       # Clase base para repositorios
│   │   ├── cache.py                 # Adaptador de cache (Redis opcional)
│   │   ├── backup.py                # Sistema de backup automático
│   │   └── constants.py             # Constantes globales
│   │
│   ├── models/                      # Modelos SQLAlchemy
│   │   ├── __init__.py
│   │   ├── user.py                  # Modelo Usuario
│   │   ├── role.py                  # Modelo Rol
│   │   ├── user_profile.py          # Modelo Perfil de Usuario
│   │   ├── home.py                  # Modelo Vivienda
│   │   ├── device.py                # Modelo Dispositivo IoT
│   │   ├── energy_reading.py        # Modelo Lectura Energética
│   │   ├── saving_goal.py           # Modelo Meta de Ahorro
│   │   ├── alert.py                 # Modelo Alerta
│   │   ├── alert_rule.py            # Modelo Regla de Alerta
│   │   ├── notification.py          # Modelo Notificación
│   │   ├── recommendation.py        # Modelo Recomendación
│   │   ├── ai_conversation.py       # Modelo Conversación IA
│   │   ├── ai_message.py            # Modelo Mensaje IA
│   │   ├── payment.py               # Modelo Pago
│   │   ├── invoice.py               # Modelo Factura
│   │   ├── subscription.py          # Modelo Suscripción
│   │   ├── activity_log.py          # Modelo Log de Actividad
│   │   ├── achievement.py           # Modelo Logro/Gamificación
│   │   ├── user_achievement.py      # Modelo relación Usuario-Logro
│   │   ├── email_verification.py    # Modelo Verificación Email
│   │   ├── password_reset.py        # Modelo Reset de Contraseña
│   │   ├── token_blacklist.py       # Modelo Blacklist de Tokens
│   │   └── system_event.py          # Modelo Eventos del Sistema
│   │
│   ├── auth/                        # Módulo de Autenticación
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints auth (/register, /login, /logout, etc.)
│   │   ├── service.py               # Lógica de negocio auth
│   │   ├── repository.py            # Acceso a datos auth
│   │   └── schemas.py               # Schemas marshmallow para validación
│   │
│   ├── users/                       # Módulo de Usuarios
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints usuarios (/profile, /settings, etc.)
│   │   ├── service.py               # Lógica de negocio usuarios
│   │   ├── repository.py            # Acceso a datos usuarios
│   │   └── schemas.py               # Schemas marshmallow
│   │
│   ├── dashboard/                   # Módulo Dashboard
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints dashboard (/stats, /overview, etc.)
│   │   ├── service.py               # Lógica agregada para dashboard
│   │   └── schemas.py               # Schemas marshmallow
│   │
│   ├── energy/                      # Módulo de Consumo Energético
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints consumo (/readings, /comparisons, /export, etc.)
│   │   ├── service.py               # Lógica de negocio energía
│   │   ├── repository.py            # Acceso a datos energía
│   │   ├── schemas.py               # Schemas marshmallow
│   │   ├── simulator.py             # Simulador de datos IoT
│   │   └── constants.py             # Constantes del módulo
│   │
│   ├── devices/                     # Módulo de Dispositivos IoT
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints dispositivos (/devices, /control, etc.)
│   │   ├── service.py               # Lógica de negocio dispositivos
│   │   ├── repository.py            # Acceso a datos dispositivos
│   │   ├── schemas.py               # Schemas marshmallow
│   │   ├── events.py                # Eventos realtime dispositivos
│   │   └── constants.py             # Tipos de dispositivos
│   │
│   ├── alerts/                      # Módulo de Alertas
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints alertas (/alerts, /rules, etc.)
│   │   ├── service.py               # Lógica de negocio alertas
│   │   ├── repository.py            # Acceso a datos alertas
│   │   ├── schemas.py               # Schemas marshmallow
│   │   ├── engine.py                # Motor de evaluación de reglas
│   │   ├── events.py                # Eventos realtime alertas
│   │   └── constants.py             # Tipos de alertas
│   │
│   ├── recommendations/             # Módulo de Recomendaciones
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints recomendaciones
│   │   ├── service.py               # Lógica de negocio recomendaciones
│   │   ├── repository.py            # Acceso a datos recomendaciones
│   │   ├── schemas.py               # Schemas marshmallow
│   │   └── engine.py                # Motor de generación de recomendaciones
│   │
│   ├── payments/                    # Módulo de Pagos
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints pagos (/checkout, /history, /webhooks, etc.)
│   │   ├── service.py               # Lógica de negocio pagos
│   │   ├── repository.py            # Acceso a datos pagos
│   │   ├── schemas.py               # Schemas marshmallow
│   │   ├── stripe_adapter.py        # Adaptador Stripe
│   │   └── constants.py             # Estados de pago
│   │
│   ├── ai/                          # Módulo de Asistente IA
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints IA (/chat, /conversations, etc.)
│   │   ├── service.py               # Lógica de negocio IA
│   │   ├── repository.py            # Acceso a datos conversaciones
│   │   ├── schemas.py               # Schemas marshmallow
│   │   ├── provider_base.py         # Interfaz base para proveedores IA
│   │   ├── openai_provider.py       # Implementación OpenAI
│   │   ├── factory.py               # Factory para seleccionar provider
│   │   └── constants.py             # Constantes IA
│   │
│   ├── notifications/               # Módulo de Notificaciones
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints notificaciones
│   │   ├── service.py               # Lógica de negocio notificaciones
│   │   ├── repository.py            # Acceso a datos notificaciones
│   │   ├── schemas.py               # Schemas marshmallow
│   │   ├── email_provider.py        # Adaptador SendGrid/Gmail
│   │   ├── sms_provider.py          # Adaptador Twilio SMS
│   │   ├── whatsapp_provider.py     # Adaptador Twilio WhatsApp
│   │   ├── websocket_provider.py    # Emisión WebSocket
│   │   └── constants.py             # Tipos de notificación
│   │
│   ├── reports/                     # Módulo de Reportes
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints reportes (/generate, /download, etc.)
│   │   ├── service.py               # Lógica de negocio reportes
│   │   ├── repository.py            # Acceso a datos reportes
│   │   ├── schemas.py               # Schemas marshmallow
│   │   └── pdf_generator.py         # Generador PDF (ReportLab)
│   │
│   ├── gamification/                # Módulo de Gamificación
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints gamificación (/achievements, /leaderboard, etc.)
│   │   ├── service.py               # Lógica de negocio gamificación
│   │   ├── repository.py            # Acceso a datos gamificación
│   │   ├── schemas.py               # Schemas marshmallow
│   │   ├── engine.py                # Motor de evaluación de logros
│   │   └── constants.py             # Definición de logros
│   │
│   ├── admin/                       # Módulo de Administración
│   │   ├── __init__.py
│   │   ├── routes.py                # Endpoints admin (/users, /stats, /system, etc.)
│   │   ├── service.py               # Lógica de negocio admin
│   │   ├── repository.py            # Acceso a datos admin
│   │   └── schemas.py               # Schemas marshmallow
│   │
│   ├── integrations/                # Módulo de Integraciones Externas
│   │   ├── __init__.py
│   │   ├── weather_service.py       # Servicio OpenWeatherMap
│   │   ├── geolocation_service.py   # Servicio de geolocalización
│   │   └── constants.py             # Configuración APIs externas
│   │
│   └── websockets/                  # Módulo WebSockets
│       ├── __init__.py
│       ├── handlers.py              # Handlers de eventos WebSocket
│       └── events.py                # Definición de eventos
│
├── migrations/                      # Migraciones de base de datos (Flask-Migrate)
│   └── versions/                    # Versiones de migración
│
├── frontend/                        # Código frontend
│   ├── index.html                   # Landing page principal
│   │
│   ├── pages/                       # Páginas HTML
│   │   ├── auth/
│   │   │   ├── login.html           # Página login
│   │   │   ├── register.html        # Página registro
│   │   │   ├── verify-email.html    # Página verificación email
│   │   │   ├── forgot-password.html # Página recuperar contraseña
│   │   │   └── change-password.html # Página cambio obligatorio contraseña
│   │   │
│   │   └── dashboard/
│   │       ├── index.html           # Dashboard principal
│   │       ├── energy.html          # Vista consumo energético
│   │       ├── devices.html         # Vista dispositivos
│   │       ├── alerts.html          # Vista alertas
│   │       ├── recommendations.html # Vista recomendaciones
│   │       ├── payments.html        # Vista pagos
│   │       ├── ai-assistant.html    # Vista asistente IA
│   │       ├── profile.html         # Vista perfil
│   │       ├── history.html         # Vista historial
│   │       ├── achievements.html    # Vista logros
│   │       └── admin.html           # Panel admin
│   │
│   ├── assets/
│   │   ├── css/
│   │   │   ├── main.css             # Estilos globales
│   │   │   ├── landing.css          # Estilos landing
│   │   │   ├── auth.css             # Estilos autenticación
│   │   │   ├── dashboard.css        # Estilos dashboard
│   │   │   ├── components.css       # Estilos componentes reutilizables
│   │   │   ├── themes.css           # Temas claro/oscuro
│   │   │   └── animations.css       # Animaciones y transiciones
│   │   │
│   │   ├── js/
│   │   │   ├── main.js              # Entry point principal
│   │   │   ├── config.js            # Configuración frontend
│   │   │   ├── api-client.js        # Cliente HTTP para API
│   │   │   ├── auth.js              # Gestión autenticación frontend
│   │   │   ├── theme.js             # Gestión tema claro/oscuro
│   │   │   ├── charts.js            # Wrapper Chart.js
│   │   │   ├── notifications.js     # Sistema de notificaciones UI
│   │   │   ├── websocket.js         # Cliente WebSocket
│   │   │   ├── storage.js           # LocalStorage/SessionStorage helper
│   │   │   ├── offline-sync.js      # Sincronización offline básica
│   │   │   ├── assistant-chat.js    # Lógica chat asistente IA
│   │   │   ├── payments.js          # Integración Stripe frontend
│   │   │   ├── alerts-manager.js    # Gestión alertas frontend
│   │   │   ├── devices-manager.js   # Gestión dispositivos frontend
│   │   │   ├── energy-charts.js     # Gráficos consumo energético
│   │   │   ├── recommendations.js   # Gestión recomendaciones
│   │   │   ├── gamification.js      # Gestión logros/gamificación
│   │   │   └── utils.js             # Utilidades generales
│   │   │
│   │   ├── img/
│   │   │   ├── logo.svg             # Logo Nexergy
│   │   │   ├── hero-bg.jpg          # Imagen hero landing
│   │   │   ├── carousel/            # Imágenes carrusel dashboard
│   │   │   └── placeholders/        # Placeholders varios
│   │   │
│   │   └── icons/                   # Iconografía SVG
│   │
│   └── components/                  # Componentes JS reutilizables
│       ├── navbar.js                # Barra navegación
│       ├── sidebar.js               # Barra lateral dashboard
│       ├── modal.js                 # Sistema modal
│       ├── toast.js                 # Notificaciones toast
│       ├── card.js                  # Componente tarjeta
│       ├── chart-widget.js          # Widget gráfico reutilizable
│       ├── device-card.js           # Tarjeta dispositivo
│       ├── alert-card.js            # Tarjeta alerta
│       └── recommendation-card.js   # Tarjeta recomendación
│
├── tests/                           # Tests
│   ├── __init__.py
│   ├── conftest.py                  # Configuración pytest
│   ├── unit/                        # Tests unitarios
│   │   ├── test_auth_service.py
│   │   ├── test_energy_service.py
│   │   ├── test_devices_service.py
│   │   ├── test_alerts_service.py
│   │   └── ...
│   ├── integration/                 # Tests de integración
│   │   ├── test_auth_flow.py
│   │   ├── test_payment_flow.py
│   │   └── ...
│   └── api/                         # Tests de API
│       ├── test_auth_endpoints.py
│       ├── test_energy_endpoints.py
│       └── ...
│
├── scripts/                         # Scripts operativos
│   ├── bootstrap.py                 # Script inicial setup
│   ├── seed_database.py             # Seed datos de prueba
│   ├── backup.py                    # Script backup manual
│   ├── simulate_iot.py              # Simulador dispositivos IoT
│   └── generate_achievements.py     # Generador logros
│
└── docs/                            # Documentación adicional
    ├── api-endpoints.md             # Especificación completa API REST
    ├── database-schema.md           # Esquema detallado BD
    ├── deployment.md                # Guía de despliegue
    └── diagrams/                    # Diagramas arquitectura
        ├── auth-flow.mmd
        ├── data-model.mmd
        └── realtime-flow.mmd
```

---

## Descripción de Archivos Principales

### Raíz del Proyecto

- **`.env.example`**: Plantilla de variables de entorno (keys API, DB credentials, secrets JWT)
- **`requirements.txt`**: Todas las dependencias Python del proyecto
- **`run.py`**: Entry point desarrollo (ejecuta Flask development server)
- **`wsgi.py`**: Entry point producción con servidor WSGI (Gunicorn)
- **`asgi.py`**: Entry point producción ASGI para WebSockets (Uvicorn/Hypercorn)
- **`config.py`**: Configuración centralizada (desarrollo, testing, producción)

### Backend Core (`app/core/`)

- **`security.py`**: Funciones de sanitización, prevención XSS/CSRF/SQL injection
- **`validators.py`**: Validadores custom (email, contraseña fuerte, etc.)
- **`errors.py`**: Manejadores de excepciones personalizadas y errores HTTP
- **`decorators.py`**: Decoradores para protección de rutas (auth required, roles, rate limit)
- **`jwt_helpers.py`**: Generación, verificación y blacklist de tokens JWT
- **`bcrypt_helpers.py`**: Hash y verificación de contraseñas
- **`base_service.py`**: Clase base abstracta para servicios con patrones comunes
- **`base_repository.py`**: Clase base abstracta para repositorios con operaciones CRUD
- **`cache.py`**: Adaptador de cache (Redis opcional, fallback en memoria)
- **`backup.py`**: Sistema de backup automático de base de datos

### Modelos (`app/models/`)

Cada modelo representa una tabla en MariaDB usando SQLAlchemy ORM:

- **`user.py`**: Usuario (id, email, password_hash, is_verified, is_active, force_password_change, created_at, updated_at)
- **`role.py`**: Rol (id, name, description)
- **`user_profile.py`**: Perfil extendido (user_id, first_name, last_name, phone, avatar, preferences_json)
- **`home.py`**: Vivienda (id, user_id, name, address, city, country, lat, lon, timezone)
- **`device.py`**: Dispositivo IoT (id, home_id, name, type, status, last_reading, metadata_json)
- **`energy_reading.py`**: Lectura energética (id, home_id, device_id, timestamp, kwh, voltage, current, power_factor)
- **`saving_goal.py`**: Meta de ahorro (id, user_id, target_kwh, target_date, status)
- **`alert.py`**: Alerta generada (id, user_id, rule_id, type, title, message, severity, is_read, created_at)
- **`alert_rule.py`**: Regla de alerta (id, user_id, name, condition_json, is_active)
- **`notification.py`**: Notificación enviada (id, user_id, channel, title, message, sent_at, status)
- **`recommendation.py`**: Recomendación (id, user_id, type, title, description, impact_kwh, created_at, is_applied)
- **`ai_conversation.py`**: Conversación IA (id, user_id, title, created_at, updated_at)
- **`ai_message.py`**: Mensaje IA (id, conversation_id, role, content, timestamp)
- **`payment.py`**: Pago (id, user_id, amount, currency, status, stripe_payment_id, created_at)
- **`invoice.py`**: Factura (id, user_id, payment_id, invoice_number, pdf_url, created_at)
- **`subscription.py`**: Suscripción (id, user_id, plan, status, stripe_subscription_id, current_period_end)
- **`activity_log.py`**: Log de actividad (id, user_id, action, resource, ip, user_agent, timestamp)
- **`achievement.py`**: Logro disponible (id, key, name, description, icon, criteria_json)
- **`user_achievement.py`**: Logro desbloqueado (user_id, achievement_id, unlocked_at, progress)
- **`email_verification.py`**: Verificación email (id, user_id, token, expires_at, verified_at)
- **`password_reset.py`**: Reset contraseña (id, user_id, token, expires_at, used_at)
- **`token_blacklist.py`**: Tokens revocados (id, jti, token_type, expires_at, blacklisted_at)
- **`system_event.py`**: Eventos del sistema (id, type, payload_json, created_at)

### Módulos de Dominio

Cada módulo sigue estructura similar:

- **`routes.py`**: Define endpoints REST del módulo
- **`service.py`**: Lógica de negocio, orquestación, validaciones
- **`repository.py`**: Acceso a datos, queries, operaciones CRUD
- **`schemas.py`**: Schemas Marshmallow para validación y serialización
- **`events.py`**: (opcional) Eventos WebSocket del módulo
- **`constants.py`**: (opcional) Constantes específicas del módulo

### Frontend

- **`index.html`**: Landing page con secciones hero, beneficios, cómo funciona, testimonios, CTA
- **`pages/auth/*.html`**: Páginas de flujo de autenticación
- **`pages/dashboard/*.html`**: Vistas del dashboard (una por sección funcional)
- **`assets/css/*.css`**: Estilos organizados por scope (global, landing, auth, dashboard, componentes, temas)
- **`assets/js/*.js`**: Módulos JS con responsabilidades específicas (API client, auth, charts, WebSockets, etc.)
- **`components/*.js`**: Componentes JS reutilizables (navbar, sidebar, modal, toast, cards)

---

## Esquema de Base de Datos Completo

### Modelo Entidad-Relación

```mermaid
erDiagram
    USERS ||--|| USER_PROFILES : has
    USERS }o--o{ ROLES : assigned
    USERS ||--o{ HOMES : owns
    HOMES ||--o{ DEVICES : contains
    HOMES ||--o{ ENERGY_READINGS : records
    DEVICES ||--o{ ENERGY_READINGS : generates
    USERS ||--o{ SAVING_GOALS : sets
    USERS ||--o{ ALERTS : receives
    ALERT_RULES ||--o{ ALERTS : generates
    USERS ||--o{ ALERT_RULES : creates
    USERS ||--o{ NOTIFICATIONS : receives
    USERS ||--o{ RECOMMENDATIONS : receives
    USERS ||--o{ AI_CONVERSATIONS : starts
    AI_CONVERSATIONS ||--o{ AI_MESSAGES : contains
    USERS ||--o{ PAYMENTS : makes
    PAYMENTS ||--|| INVOICES : has
    USERS ||--o{ SUBSCRIPTIONS : subscribes
    USERS ||--o{ ACTIVITY_LOGS : generates
    USERS }o--o{ ACHIEVEMENTS : unlocks
    USERS ||--o{ EMAIL_VERIFICATIONS : requests
    USERS ||--o{ PASSWORD_RESETS : requests
```

### Tablas y Campos Detallados

#### `users`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| email | VARCHAR(255) | UNIQUE, NOT NULL, INDEX | Email del usuario |
| password_hash | VARCHAR(255) | NOT NULL | Hash bcrypt de contraseña |
| is_verified | BOOLEAN | DEFAULT FALSE | Email verificado |
| is_active | BOOLEAN | DEFAULT TRUE | Cuenta activa |
| force_password_change | BOOLEAN | DEFAULT FALSE | Requiere cambio contraseña |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |
| updated_at | DATETIME | ON UPDATE CURRENT_TIMESTAMP | Última actualización |

**Índices:**
- PRIMARY KEY (id)
- UNIQUE INDEX (email)
- INDEX (is_active, is_verified)

#### `roles`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| name | VARCHAR(50) | UNIQUE, NOT NULL | Nombre del rol (user, admin) |
| description | TEXT | NULL | Descripción del rol |

**Índices:**
- PRIMARY KEY (id)
- UNIQUE INDEX (name)

#### `user_roles` (tabla relación many-to-many)
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| user_id | INT | FK, NOT NULL | Referencia a users |
| role_id | INT | FK, NOT NULL | Referencia a roles |

**Índices:**
- PRIMARY KEY (user_id, role_id)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
- FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE

#### `user_profiles`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, UNIQUE, NOT NULL | Referencia a users |
| first_name | VARCHAR(100) | NULL | Nombre |
| last_name | VARCHAR(100) | NULL | Apellido |
| phone | VARCHAR(20) | NULL | Teléfono |
| avatar | VARCHAR(255) | NULL | URL avatar |
| preferences_json | JSON | NULL | Preferencias usuario |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |
| updated_at | DATETIME | ON UPDATE CURRENT_TIMESTAMP | Última actualización |

**Índices:**
- PRIMARY KEY (id)
- UNIQUE INDEX (user_id)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `homes`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| name | VARCHAR(100) | NOT NULL | Nombre vivienda |
| address | VARCHAR(255) | NULL | Dirección |
| city | VARCHAR(100) | NULL | Ciudad |
| country | VARCHAR(100) | NULL | País |
| lat | DECIMAL(10,8) | NULL | Latitud |
| lon | DECIMAL(11,8) | NULL | Longitud |
| timezone | VARCHAR(50) | NULL | Zona horaria |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |
| updated_at | DATETIME | ON UPDATE CURRENT_TIMESTAMP | Última actualización |

**Índices:**
- PRIMARY KEY (id)
- INDEX (user_id)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `devices`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| home_id | INT | FK, NOT NULL | Referencia a homes |
| name | VARCHAR(100) | NOT NULL | Nombre dispositivo |
| type | VARCHAR(50) | NOT NULL | Tipo (smart_meter, light, ac, heater, etc.) |
| status | VARCHAR(20) | DEFAULT 'offline' | Estado (online, offline, error) |
| last_reading | DATETIME | NULL | Última lectura |
| metadata_json | JSON | NULL | Metadata adicional |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |
| updated_at | DATETIME | ON UPDATE CURRENT_TIMESTAMP | Última actualización |

**Índices:**
- PRIMARY KEY (id)
- INDEX (home_id, status)
- INDEX (type)
- FOREIGN KEY (home_id) REFERENCES homes(id) ON DELETE CASCADE

#### `energy_readings`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | BIGINT | PK, AUTO_INCREMENT | ID único |
| home_id | INT | FK, NOT NULL | Referencia a homes |
| device_id | INT | FK, NULL | Referencia a devices |
| timestamp | DATETIME | NOT NULL, INDEX | Momento de lectura |
| kwh | DECIMAL(10,4) | NOT NULL | Consumo en kWh |
| voltage | DECIMAL(6,2) | NULL | Voltaje |
| current | DECIMAL(6,2) | NULL | Corriente |
| power_factor | DECIMAL(4,3) | NULL | Factor de potencia |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |

**Índices:**
- PRIMARY KEY (id)
- INDEX (home_id, timestamp DESC)
- INDEX (device_id, timestamp DESC)
- FOREIGN KEY (home_id) REFERENCES homes(id) ON DELETE CASCADE
- FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE SET NULL

#### `saving_goals`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| target_kwh | DECIMAL(10,2) | NOT NULL | Meta consumo kWh |
| target_date | DATE | NOT NULL | Fecha objetivo |
| status | VARCHAR(20) | DEFAULT 'active' | Estado (active, achieved, failed) |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |
| updated_at | DATETIME | ON UPDATE CURRENT_TIMESTAMP | Última actualización |

**Índices:**
- PRIMARY KEY (id)
- INDEX (user_id, status)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `alert_rules`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| name | VARCHAR(100) | NOT NULL | Nombre regla |
| condition_json | JSON | NOT NULL | Condición evaluable |
| is_active | BOOLEAN | DEFAULT TRUE | Regla activa |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |
| updated_at | DATETIME | ON UPDATE CURRENT_TIMESTAMP | Última actualización |

**Índices:**
- PRIMARY KEY (id)
- INDEX (user_id, is_active)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `alerts`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| rule_id | INT | FK, NULL | Referencia a alert_rules |
| type | VARCHAR(50) | NOT NULL | Tipo alerta |
| title | VARCHAR(200) | NOT NULL | Título |
| message | TEXT | NOT NULL | Mensaje |
| severity | VARCHAR(20) | DEFAULT 'info' | Severidad (info, warning, critical) |
| is_read | BOOLEAN | DEFAULT FALSE | Leída |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |

**Índices:**
- PRIMARY KEY (id)
- INDEX (user_id, is_read, created_at DESC)
- INDEX (severity)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
- FOREIGN KEY (rule_id) REFERENCES alert_rules(id) ON DELETE SET NULL

#### `notifications`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| channel | VARCHAR(20) | NOT NULL | Canal (email, sms, whatsapp, push) |
| title | VARCHAR(200) | NOT NULL | Título |
| message | TEXT | NOT NULL | Mensaje |
| sent_at | DATETIME | NULL | Fecha envío |
| status | VARCHAR(20) | DEFAULT 'pending' | Estado (pending, sent, failed) |
| metadata_json | JSON | NULL | Metadata adicional |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |

**Índices:**
- PRIMARY KEY (id)
- INDEX (user_id, status, created_at DESC)
- INDEX (channel, status)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `recommendations`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| type | VARCHAR(50) | NOT NULL | Tipo recomendación |
| title | VARCHAR(200) | NOT NULL | Título |
| description | TEXT | NOT NULL | Descripción |
| impact_kwh | DECIMAL(8,2) | NULL | Impacto estimado kWh |
| is_applied | BOOLEAN | DEFAULT FALSE | Aplicada |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |

**Índices:**
- PRIMARY KEY (id)
- INDEX (user_id, is_applied, created_at DESC)
- INDEX (type)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `ai_conversations`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| title | VARCHAR(200) | NULL | Título conversación |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |
| updated_at | DATETIME | ON UPDATE CURRENT_TIMESTAMP | Última actualización |

**Índices:**
- PRIMARY KEY (id)
- INDEX (user_id, updated_at DESC)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `ai_messages`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | BIGINT | PK, AUTO_INCREMENT | ID único |
| conversation_id | INT | FK, NOT NULL | Referencia a ai_conversations |
| role | VARCHAR(20) | NOT NULL | Rol (user, assistant, system) |
| content | TEXT | NOT NULL | Contenido mensaje |
| timestamp | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha mensaje |

**Índices:**
- PRIMARY KEY (id)
- INDEX (conversation_id, timestamp ASC)
- FOREIGN KEY (conversation_id) REFERENCES ai_conversations(id) ON DELETE CASCADE

#### `payments`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| amount | DECIMAL(10,2) | NOT NULL | Monto |
| currency | VARCHAR(3) | DEFAULT 'USD' | Moneda |
| status | VARCHAR(20) | DEFAULT 'pending' | Estado (pending, completed, failed, refunded) |
| stripe_payment_id | VARCHAR(255) | NULL, INDEX | ID Stripe |
| metadata_json | JSON | NULL | Metadata adicional |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |
| updated_at | DATETIME | ON UPDATE CURRENT_TIMESTAMP | Última actualización |

**Índices:**
- PRIMARY KEY (id)
- INDEX (user_id, created_at DESC)
- INDEX (stripe_payment_id)
- INDEX (status)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `invoices`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| payment_id | INT | FK, NULL | Referencia a payments |
| invoice_number | VARCHAR(50) | UNIQUE, NOT NULL | Número factura |
| pdf_url | VARCHAR(255) | NULL | URL PDF |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |

**Índices:**
- PRIMARY KEY (id)
- UNIQUE INDEX (invoice_number)
- INDEX (user_id, created_at DESC)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
- FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE SET NULL

#### `subscriptions`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| plan | VARCHAR(50) | NOT NULL | Plan (basic, premium, enterprise) |
| status | VARCHAR(20) | DEFAULT 'active' | Estado (active, canceled, past_due) |
| stripe_subscription_id | VARCHAR(255) | NULL, INDEX | ID Stripe |
| current_period_end | DATETIME | NULL | Fin periodo actual |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |
| updated_at | DATETIME | ON UPDATE CURRENT_TIMESTAMP | Última actualización |

**Índices:**
- PRIMARY KEY (id)
- INDEX (user_id, status)
- INDEX (stripe_subscription_id)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `activity_logs`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | BIGINT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NULL | Referencia a users |
| action | VARCHAR(100) | NOT NULL | Acción realizada |
| resource | VARCHAR(100) | NULL | Recurso afectado |
| ip | VARCHAR(45) | NULL | IP origen |
| user_agent | VARCHAR(255) | NULL | User agent |
| metadata_json | JSON | NULL | Metadata adicional |
| timestamp | DATETIME | DEFAULT CURRENT_TIMESTAMP, INDEX | Fecha acción |

**Índices:**
- PRIMARY KEY (id)
- INDEX (user_id, timestamp DESC)
- INDEX (action, timestamp DESC)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL

#### `achievements`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| key | VARCHAR(50) | UNIQUE, NOT NULL | Clave única logro |
| name | VARCHAR(100) | NOT NULL | Nombre |
| description | TEXT | NOT NULL | Descripción |
| icon | VARCHAR(50) | NULL | Icono |
| criteria_json | JSON | NOT NULL | Criterios evaluables |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |

**Índices:**
- PRIMARY KEY (id)
- UNIQUE INDEX (key)

#### `user_achievements`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| user_id | INT | FK, NOT NULL | Referencia a users |
| achievement_id | INT | FK, NOT NULL | Referencia a achievements |
| unlocked_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha desbloqueo |
| progress | DECIMAL(5,2) | DEFAULT 0.00 | Progreso (0-100) |

**Índices:**
- PRIMARY KEY (user_id, achievement_id)
- INDEX (user_id, unlocked_at DESC)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
- FOREIGN KEY (achievement_id) REFERENCES achievements(id) ON DELETE CASCADE

#### `email_verifications`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| token | VARCHAR(255) | UNIQUE, NOT NULL, INDEX | Token verificación |
| expires_at | DATETIME | NOT NULL | Fecha expiración |
| verified_at | DATETIME | NULL | Fecha verificación |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |

**Índices:**
- PRIMARY KEY (id)
- UNIQUE INDEX (token)
- INDEX (user_id)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `password_resets`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| user_id | INT | FK, NOT NULL | Referencia a users |
| token | VARCHAR(255) | UNIQUE, NOT NULL, INDEX | Token reset |
| expires_at | DATETIME | NOT NULL | Fecha expiración |
| used_at | DATETIME | NULL | Fecha uso |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha creación |

**Índices:**
- PRIMARY KEY (id)
- UNIQUE INDEX (token)
- INDEX (user_id)
- FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE

#### `token_blacklist`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | INT | PK, AUTO_INCREMENT | ID único |
| jti | VARCHAR(255) | UNIQUE, NOT NULL, INDEX | JWT ID |
| token_type | VARCHAR(20) | NOT NULL | Tipo (access, refresh) |
| expires_at | DATETIME | NOT NULL | Fecha expiración |
| blacklisted_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Fecha blacklist |

**Índices:**
- PRIMARY KEY (id)
- UNIQUE INDEX (jti)
- INDEX (expires_at)

#### `system_events`
| Campo | Tipo | Constraints | Descripción |
|-------|------|-------------|-------------|
| id | BIGINT | PK, AUTO_INCREMENT | ID único |
| type | VARCHAR(50) | NOT NULL | Tipo evento |
| payload_json | JSON | NULL | Payload evento |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP, INDEX | Fecha evento |

**Índices:**
- PRIMARY KEY (id)
- INDEX (type, created_at DESC)

---

## Flujo de Autenticación

### Diagrama de Flujo Completo

```mermaid
flowchart TD
    A[Usuario accede a registro] --> B[Completa formulario]
    B --> C[Backend valida datos]
    C --> D{¿Válido?}
    D -->|No| E[Retorna errores validación]
    E --> B
    D -->|Sí| F[Genera contraseña provisional]
    F --> G[Hash bcrypt de contraseña]
    G --> H[Crea usuario con force_password_change=true]
    H --> I[Genera token verificación email]
    I --> J[Envía email con credenciales + link verificación]
    J --> K[Usuario recibe email]
    K --> L[Clic en link verificación]
    L --> M[Backend valida token]
    M --> N{¿Token válido?}
    N -->|No| O[Error token expirado/inválido]
    N -->|Sí| P[Marca is_verified=true]
    P --> Q[Usuario hace login con credenciales provisionales]
    Q --> R[Backend valida email/password]
    R --> S{¿Credenciales válidas?}
    S -->|No| T[Error autenticación]
    S -->|Sí| U{¿force_password_change?}
    U -->|Sí| V[Redirige a cambio obligatorio contraseña]
    V --> W[Usuario ingresa nueva contraseña]
    W --> X[Backend valida contraseña fuerte]
    X --> Y[Hash nueva contraseña]
    Y --> Z[Actualiza password_hash, force_password_change=false]
    Z --> AA[Genera access_token y refresh_token JWT]
    U -->|No| AA
    AA --> AB[Retorna tokens al frontend]
    AB --> AC[Frontend guarda tokens]
    AC --> AD[Acceso a dashboard]
    AD --> AE[Peticiones con Authorization: Bearer access_token]
    AE --> AF{¿Token válido?}
    AF -->|No| AG{¿Token expirado?}
    AG -->|Sí| AH[Frontend usa refresh_token]
    AH --> AI[Backend valida refresh_token]
    AI --> AJ{¿Refresh válido?}
    AJ -->|No| AK[Logout forzado, redirige a login]
    AJ -->|Sí| AL[Genera nuevo access_token]
    AL --> AC
    AG -->|No| AK
    AF -->|Sí| AM[Procesa petición]
    AM --> AN{¿Requiere admin?}
    AN -->|Sí| AO{¿Usuario tiene rol admin?}
    AO -->|No| AP[Error 403 Forbidden]
    AO -->|Sí| AQ[Procesa petición admin]
    AN -->|No| AQ
```

### Protecciones de Seguridad

1. **XSS (Cross-Site Scripting)**
   - Sanitización de inputs en backend
   - Content Security Policy (CSP) headers
   - Escapado de outputs en frontend

2. **CSRF (Cross-Site Request Forgery)**
   - SameSite cookies
   - CSRF tokens en formularios críticos
   - Validación de origen en peticiones sensibles

3. **SQL Injection**
   - Uso exclusivo de SQLAlchemy ORM
   - Prepared statements
   - Validación de tipos de datos

4. **Brute Force**
   - Rate limiting en endpoints auth
   - Bloqueo temporal tras intentos fallidos
   - CAPTCHA en intentos sospechosos

5. **Session Hijacking**
   - JWT con tiempo de expiración corto (15 min access, 7 días refresh)
   - Rotación de refresh tokens
   - Blacklist de tokens en logout
   - Validación de user-agent e IP en operaciones críticas

6. **Password Security**
   - Bcrypt con salt automático
   - Validación de contraseña fuerte (mínimo 8 caracteres, mayúsculas, minúsculas, números, símbolos)
   - Forzado de cambio en primera sesión
   - Historial de contraseñas (no reutilizar últimas 3)

---

## Endpoints REST Completos

### Autenticación (`/api/v1/auth`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| POST | `/register` | No | - | Registro de nuevo usuario |
| POST | `/login` | No | - | Login con email/password |
| POST | `/logout` | Sí | - | Logout y blacklist de token |
| POST | `/refresh` | Sí (refresh) | - | Renovar access token |
| POST | `/verify-email` | No | - | Verificar email con token |
| POST | `/resend-verification` | No | - | Reenviar email verificación |
| POST | `/forgot-password` | No | - | Solicitar reset de contraseña |
| POST | `/reset-password` | No | - | Resetear contraseña con token |
| POST | `/change-password` | Sí | - | Cambiar contraseña (requiere actual) |
| GET | `/me` | Sí | - | Obtener usuario autenticado |

### Usuarios (`/api/v1/users`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/profile` | Sí | - | Obtener perfil usuario |
| PUT | `/profile` | Sí | - | Actualizar perfil usuario |
| GET | `/settings` | Sí | - | Obtener configuraciones |
| PUT | `/settings` | Sí | - | Actualizar configuraciones |
| POST | `/avatar` | Sí | - | Subir avatar |
| DELETE | `/avatar` | Sí | - | Eliminar avatar |

### Dashboard (`/api/v1/dashboard`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/overview` | Sí | - | Resumen general dashboard |
| GET | `/stats` | Sí | - | Estadísticas agregadas |
| GET | `/weather` | Sí | - | Clima actual ubicación |
| GET | `/carousel` | Sí | - | Imágenes carrusel personalizadas |

### Energía (`/api/v1/energy`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/readings` | Sí | - | Lecturas energéticas (filtros: período, device) |
| GET | `/readings/:id` | Sí | - | Detalle lectura específica |
| GET | `/consumption/daily` | Sí | - | Consumo diario |
| GET | `/consumption/monthly` | Sí | - | Consumo mensual |
| GET | `/consumption/yearly` | Sí | - | Consumo anual |
| GET | `/comparisons` | Sí | - | Comparativas (mes anterior, año anterior, promedio) |
| GET | `/export/pdf` | Sí | - | Exportar reporte PDF |
| GET | `/export/csv` | Sí | - | Exportar datos CSV |
| GET | `/goals` | Sí | - | Obtener metas de ahorro |
| POST | `/goals` | Sí | - | Crear meta de ahorro |
| PUT | `/goals/:id` | Sí | - | Actualizar meta |
| DELETE | `/goals/:id` | Sí | - | Eliminar meta |

### Dispositivos (`/api/v1/devices`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/` | Sí | - | Listar dispositivos usuario |
| GET | `/:id` | Sí | - | Detalle dispositivo |
| POST | `/` | Sí | - | Registrar nuevo dispositivo |
| PUT | `/:id` | Sí | - | Actualizar dispositivo |
| DELETE | `/:id` | Sí | - | Eliminar dispositivo |
| POST | `/:id/control` | Sí | - | Controlar dispositivo (on/off, ajustes) |
| GET | `/:id/status` | Sí | - | Estado en tiempo real |
| GET | `/:id/history` | Sí | - | Historial de estados |

### Alertas (`/api/v1/alerts`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/` | Sí | - | Listar alertas usuario |
| GET | `/:id` | Sí | - | Detalle alerta |
| PUT | `/:id/read` | Sí | - | Marcar como leída |
| DELETE | `/:id` | Sí | - | Eliminar alerta |
| GET | `/rules` | Sí | - | Listar reglas de alerta |
| POST | `/rules` | Sí | - | Crear regla |
| PUT | `/rules/:id` | Sí | - | Actualizar regla |
| DELETE | `/rules/:id` | Sí | - | Eliminar regla |
| POST | `/rules/:id/toggle` | Sí | - | Activar/desactivar regla |

### Recomendaciones (`/api/v1/recommendations`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/` | Sí | - | Listar recomendaciones usuario |
| GET | `/:id` | Sí | - | Detalle recomendación |
| POST | `/:id/apply` | Sí | - | Marcar como aplicada |
| DELETE | `/:id` | Sí | - | Descartar recomendación |
| POST | `/generate` | Sí | - | Generar nuevas recomendaciones |

### Pagos (`/api/v1/payments`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/methods` | Sí | - | Listar métodos de pago guardados |
| POST | `/methods` | Sí | - | Agregar método de pago |
| DELETE | `/methods/:id` | Sí | - | Eliminar método de pago |
| POST | `/checkout` | Sí | - | Crear sesión checkout Stripe |
| GET | `/history` | Sí | - | Historial de pagos |
| GET | `/invoices` | Sí | - | Listar facturas |
| GET | `/invoices/:id/pdf` | Sí | - | Descargar factura PDF |
| GET | `/subscriptions` | Sí | - | Obtener suscripciones |
| POST | `/subscriptions` | Sí | - | Crear suscripción |
| PUT | `/subscriptions/:id` | Sí | - | Actualizar suscripción |
| DELETE | `/subscriptions/:id` | Sí | - | Cancelar suscripción |
| POST | `/webhooks/stripe` | No | - | Webhook Stripe eventos |

### Asistente IA (`/api/v1/ai`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/conversations` | Sí | - | Listar conversaciones usuario |
| POST | `/conversations` | Sí | - | Crear nueva conversación |
| GET | `/conversations/:id` | Sí | - | Obtener conversación con mensajes |
| DELETE | `/conversations/:id` | Sí | - | Eliminar conversación |
| POST | `/chat` | Sí | - | Enviar mensaje y recibir respuesta |
| GET | `/providers` | Sí | admin | Listar proveedores IA disponibles |
| GET | `/providers/active` | Sí | admin | Obtener proveedor activo |
| PUT | `/providers/active` | Sí | admin | Cambiar proveedor activo |

### Notificaciones (`/api/v1/notifications`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/` | Sí | - | Listar notificaciones usuario |
| GET | `/:id` | Sí | - | Detalle notificación |
| PUT | `/:id/read` | Sí | - | Marcar como leída |
| DELETE | `/:id` | Sí | - | Eliminar notificación |
| GET | `/preferences` | Sí | - | Obtener preferencias notificaciones |
| PUT | `/preferences` | Sí | - | Actualizar preferencias |
| POST | `/test` | Sí | - | Enviar notificación de prueba |

### Reportes (`/api/v1/reports`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| POST | `/generate` | Sí | - | Generar reporte personalizado |
| GET | `/templates` | Sí | - | Listar plantillas disponibles |
| GET | `/:id` | Sí | - | Obtener reporte generado |
| GET | `/:id/download` | Sí | - | Descargar PDF reporte |

### Historial (`/api/v1/history`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/activity` | Sí | - | Historial de actividad usuario |
| GET | `/activity/:id` | Sí | - | Detalle actividad específica |

### Gamificación (`/api/v1/gamification`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/achievements` | Sí | - | Listar logros disponibles |
| GET | `/achievements/unlocked` | Sí | - | Logros desbloqueados usuario |
| GET | `/achievements/:id` | Sí | - | Detalle logro |
| GET | `/leaderboard` | Sí | - | Tabla de posiciones |
| GET | `/progress` | Sí | - | Progreso hacia logros |

### Administración (`/api/v1/admin`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/users` | Sí | admin | Listar todos los usuarios |
| GET | `/users/:id` | Sí | admin | Detalle usuario |
| PUT | `/users/:id` | Sí | admin | Actualizar usuario |
| DELETE | `/users/:id` | Sí | admin | Eliminar usuario |
| POST | `/users/:id/reset-password` | Sí | admin | Forzar reset contraseña |
| POST | `/users/:id/toggle-active` | Sí | admin | Activar/desactivar usuario |
| GET | `/stats` | Sí | admin | Estadísticas sistema |
| GET | `/logs` | Sí | admin | Logs del sistema |
| GET | `/events` | Sí | admin | Eventos del sistema |
| POST | `/backup` | Sí | admin | Ejecutar backup manual |
| GET | `/backups` | Sí | admin | Listar backups |
| POST | `/backups/:id/restore` | Sí | admin | Restaurar backup |

### Sistema (`/api/v1/system`)

| Método | Ruta | Auth | Rol | Descripción |
|--------|------|------|-----|-------------|
| GET | `/health` | No | - | Health check |
| GET | `/version` | No | - | Versión de la API |
| GET | `/status` | Sí | admin | Estado servicios |

---

## Integraciones y Proveedores Externos

### OpenWeatherMap (Clima)
- **Uso:** Obtener clima en tiempo real basado en ubicación del usuario
- **Endpoint:** `https://api.openweathermap.org/data/2.5/weather`
- **Autenticación:** API Key
- **Datos:** Temperatura, humedad, condiciones, pronóstico

### Geolocation API
- **Uso:** Obtener coordenadas de ubicación usuario
- **Implementación:** Browser Geolocation API + backend reverse geocoding
- **Fallback:** IP-based geolocation

### Stripe (Pagos)
- **Uso:** Procesamiento de pagos, suscripciones, facturación
- **SDK:** `stripe` (Python), Stripe.js (frontend)
- **Autenticación:** Secret Key (backend), Publishable Key (frontend)
- **Webhooks:** Eventos de pago, suscripción, factura
- **Endpoints:** Checkout, Payment Intents, Subscriptions, Invoices

### SendGrid / Gmail (Email)
- **Uso:** Emails transaccionales (verificación, recuperación contraseña, notificaciones)
- **Autenticación:** API Key (SendGrid) o SMTP (Gmail)
- **Plantillas:** HTML templates personalizadas
- **Tracking:** Apertura, clics (SendGrid)

### Twilio (SMS y WhatsApp)
- **Uso:** Notificaciones por SMS y WhatsApp
- **SDK:** `twilio` (Python)
- **Autenticación:** Account SID + Auth Token
- **Servicios:**
  - SMS: Mensajes de texto cortos
  - WhatsApp: Mensajes plantilla y conversacionales

### OpenAI (Asistente IA)
- **Uso:** Chat conversacional, recomendaciones personalizadas
- **SDK:** `openai` (Python)
- **Autenticación:** API Key
- **Modelos:** GPT-4, GPT-3.5-turbo
- **Arquitectura:** Capa abstracta multi-provider

### Capa Abstracta de IA (Multi-Provider)

```mermaid
classDiagram
    class AIProviderBase {
        <<abstract>>
        +generate_response(messages, context)
        +stream_response(messages, context)
        +get_provider_name()
    }
    class OpenAIProvider {
        +generate_response(messages, context)
        +stream_response(messages, context)
        +get_provider_name()
    }
    class AnthropicProvider {
        +generate_response(messages, context)
        +stream_response(messages, context)
        +get_provider_name()
    }
    class AIProviderFactory {
        +get_provider(provider_name)
        +get_active_provider()
        +list_available_providers()
    }
    AIProviderBase <|-- OpenAIProvider
    AIProviderBase <|-- AnthropicProvider
    AIProviderFactory --> AIProviderBase
```

**Ventajas:**
- Desacoplamiento de proveedores específicos
- Fácil migración entre proveedores
- Posibilidad de A/B testing
- Fallback automático si un proveedor falla
- Configuración centralizada

**Implementación:**
1. Interfaz base (`AIProviderBase`) con métodos abstractos
2. Implementaciones concretas por proveedor
3. Factory para seleccionar proveedor activo
4. Configuración en `.env` o base de datos
5. Rate limiting y caching por proveedor

### Simulador de Datos Energéticos
- **Uso:** Generar datos IoT realistas en ausencia de hardware real
- **Implementación:** Scheduler (APScheduler) que genera lecturas cada X minutos
- **Patrón:** Consumo base + variaciones por hora del día + picos aleatorios
- **Configuración:** Ajustable por tipo de dispositivo

---

## Decisiones Técnicas Justificadas

### 1. Monolito Modular vs Microservicios
**Decisión:** Monolito modular listo para escalar

**Justificación:**
- **Ventajas:**
  - Menor complejidad operativa inicial
  - Deployment simplificado
  - Transacciones ACID nativas
  - Desarrollo más rápido en etapas tempranas
  - Debugging más sencillo
  - Reducción de latencia inter-servicios
  
- **Preparación para escalado:**
  - Separación clara por dominios (blueprints Flask)
  - Interfaces bien definidas entre módulos
  - Cada módulo puede extraerse a servicio independiente sin romper contratos
  - Base de datos diseñada con posibilidad de particionar por dominio

**Cuándo migrar a microservicios:**
- Cuando módulos específicos requieran escalado independiente
- Cuando equipos separados trabajen en dominios distintos
- Cuando la complejidad operativa justifique la inversión

### 2. SQLAlchemy + Flask-Migrate vs Queries Manuales
**Decisión:** SQLAlchemy ORM + Flask-Migrate

**Justificación:**
- **Ventajas:**
  - Abstracción de base de datos (cambio de DB más sencillo)
  - Prevención automática de SQL injection
  - Migraciones versionadas y reversibles
  - Relaciones ORM expresivas y type-safe
  - Menor código boilerplate
  
- **Compromisos:**
  - Queries complejas pueden requerir raw SQL ocasionalmente
  - Overhead mínimo de performance (mitigable con optimizaciones)

**Mitigación:**
- Uso de SQLAlchemy Core para queries críticas de performance
- Índices estratégicos en base de datos
- Eager loading para evitar N+1 queries

### 3. Frontend Vanilla + CDN vs Framework Pesado
**Decisión:** HTML/CSS/JS vanilla + librerías ligeras por CDN

**Justificación:**
- **Ventajas:**
  - Carga inicial más rápida
  - Menor complejidad de build
  - Curva de aprendizaje baja
  - Control total sobre optimizaciones
  - Sin dependencias de build tools pesados
  
- **Librerías CDN seleccionadas:**
  - Chart.js: Gráficos interactivos
  - Socket.IO: Cliente WebSocket
  - SweetAlert2: Modales y alertas elegantes
  - Day.js: Manipulación fechas ligera
  - AOS: Animaciones on scroll

**Organización modular:**
- Módulos ES6 para separación de responsabilidades
- Componentes reutilizables sin framework
- Sistema de eventos custom para comunicación inter-módulos

### 4. Capa Abstracta IA vs Acoplamiento Directo
**Decisión:** Capa abstracta multi-provider

**Justificación:**
- **Ventajas:**
  - Flexibilidad para cambiar proveedores
  - Reducción de vendor lock-in
  - A/B testing de modelos
  - Fallback automático
  - Costos optimizables
  
- **Implementación:**
  - Interfaz base con contrato estable
  - Factory pattern para selección
  - Configuración dinámica (DB o archivo)

### 5. WebSockets vs Polling para Tiempo Real
**Decisión:** WebSockets (Flask-SocketIO)

**Justificación:**
- **Ventajas:**
  - Menor latencia
  - Menor overhead de red
  - Conexión bidireccional persistente
  - Ideal para notificaciones push
  
- **Casos de uso:**
  - Estado dispositivos en tiempo real
  - Notificaciones instantáneas
  - Actualizaciones de consumo
  - Chat asistente IA

**Escalabilidad:**
- Redis como message broker para múltiples workers
- Posibilidad de separar servidor WebSocket si es necesario

### 6. JWT vs Sessions para Autenticación
**Decisión:** JWT (access + refresh tokens)

**Justificación:**
- **Ventajas:**
  - Stateless (escalabilidad horizontal)
  - Información embebida en token
  - Compatible con arquitectura distribuida
  - Frontend puede verificar expiración
  
- **Seguridad:**
  - Access token corto (15 min)
  - Refresh token largo (7 días)
  - Blacklist para revocación
  - Rotación de refresh tokens

---

## Dependencias del Proyecto

### Backend (`requirements.txt`)

```
# Flask Core
Flask==3.0.0
Werkzeug==3.0.1

# Database
Flask-SQLAlchemy==3.1.1
Flask-Migrate==4.0.5
PyMySQL==1.1.0
cryptography==41.0.7

# Authentication & Security
Flask-JWT-Extended==4.6.0
Flask-Bcrypt==1.0.1
python-dotenv==1.0.0

# Validation & Serialization
marshmallow==3.20.1
flask-marshmallow==0.15.0
marshmallow-sqlalchemy==0.29.0

# Email
Flask-Mail==0.9.1
sendgrid==6.11.0

# SMS & WhatsApp
twilio==8.10.0

# Payments
stripe==7.8.0

# AI Providers
openai==1.5.0
anthropic==0.7.0

# Real-time
Flask-SocketIO==5.3.5
python-socketio==5.10.0
eventlet==0.33.3

# HTTP Requests
requests==2.31.0
httpx==0.25.2

# Background Jobs
APScheduler==3.10.4
celery==5.3.4  # Opcional para escalado

# Cache
redis==5.0.1  # Opcional para escalado

# PDF Generation
reportlab==4.0.7
PyPDF2==3.0.1

# Weather & Geolocation
geopy==2.4.1

# Utilities
python-dateutil==2.8.2
pytz==2023.3
click==8.1.7

# CORS
Flask-CORS==4.0.0

# Rate Limiting
Flask-Limiter==3.5.0

# Monitoring & Logging
Flask-Logging==0.1.0

# Testing
pytest==7.4.3
pytest-flask==1.3.0
pytest-cov==4.1.0
faker==20.1.0

# Development
black==23.12.1
flake8==6.1.0
mypy==1.7.1
```

### Frontend (Librerías CDN)

```html
<!-- Chart.js - Gráficos -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

<!-- Socket.IO - WebSockets -->
<script src="https://cdn.socket.io/4.6.0/socket.io.min.js"></script>

<!-- SweetAlert2 - Alertas elegantes -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Day.js - Manipulación fechas -->
<script src="https://cdn.jsdelivr.net/npm/dayjs@1.11.10/dayjs.min.js"></script>

<!-- AOS - Animaciones on scroll -->
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<!-- Font Awesome - Iconos -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<!-- Stripe.js - Pagos -->
<script src="https://js.stripe.com/v3/"></script>

<!-- html2canvas + jsPDF - Generación PDF cliente (opcional) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
```

---

## Plan de Implementación por Fases

### Fase 1: Bootstrap y Base Técnica
**Objetivo:** Estructura inicial del proyecto y configuración base

**Entregables:**
- Estructura de carpetas completa
- Configuración entorno (`.env`, `config.py`)
- Setup inicial Flask + extensiones
- Configuración base de datos MariaDB
- Sistema de logging
- Health check endpoint

**Validación:**
- `run.py` ejecuta sin errores
- Conexión a base de datos exitosa
- `/api/v1/system/health` responde correctamente

---

### Fase 2: Autenticación y Seguridad Base
**Objetivo:** Sistema completo de autenticación y protecciones

**Entregables:**
- Modelos: `users`, `roles`, `user_roles`, `user_profiles`, `email_verifications`, `password_resets`, `token_blacklist`
- Módulo `auth` completo (registro, login, logout, verificación email, reset contraseña)
- Decoradores de protección (`@jwt_required`, `@role_required`)
- Sistema JWT con access y refresh tokens
- Bcrypt para hashing
- Protecciones XSS, CSRF, SQL injection
- Rate limiting en endpoints sensibles

**Validación:**
- Flujo completo de registro funcional
- Email de verificación enviado
- Login con credenciales provisionales
- Cambio obligatorio de contraseña en primer login
- Refresh token renueva access token
- Blacklist revoca tokens correctamente

---

### Fase 3: Modelo de Datos y Migraciones
**Objetivo:** Esquema completo de base de datos

**Entregables:**
- Todos los modelos SQLAlchemy definidos
- Migraciones Flask-Migrate generadas
- Índices y relaciones configuradas
- Script de seed para datos de prueba
- Achievements predefinidos

**Validación:**
- `flask db upgrade` ejecuta sin errores
- Todas las tablas creadas
- Relaciones Foreign Key funcionales
- Seed data cargado correctamente

---

### Fase 4: Landing y Flujo Auth Frontend
**Objetivo:** Interfaz pública y flujo de autenticación

**Entregables:**
- Landing page (`index.html`) con secciones completas
- Páginas auth: login, register, verify-email, forgot-password, change-password
- CSS responsive y tema base
- JS modules: `api-client.js`, `auth.js`, `storage.js`, `utils.js`
- Validaciones frontend
- Integración con endpoints auth

**Validación:**
- Landing responsive en móvil, tablet, desktop
- Registro exitoso muestra mensaje de verificación
- Login con credenciales válidas redirige a dashboard
- Cambio de contraseña obligatorio funcional
- Recuperación de contraseña completa

---

### Fase 5: Dashboard Base y Shell UI
**Objetivo:** Estructura y navegación del dashboard

**Entregables:**
- Dashboard principal (`pages/dashboard/index.html`)
- Navbar superior (buscador, tema, notificaciones, perfil)
- Sidebar lateral (navegación módulos)
- Bienvenida personalizada
- Carrusel de imágenes
- Integración clima/ubicación
- Componentes reutilizables: navbar, sidebar, modal, toast
- JS modules: `theme.js`, `notifications.js`, `websocket.js`
- Tema claro/oscuro funcional

**Validación:**
- Dashboard carga con usuario autenticado
- Navbar muestra nombre usuario y avatar
- Sidebar navega entre secciones
- Tema se alterna y persiste
- Clima se obtiene de API externa
- WebSocket conecta correctamente

---

### Fase 6: Consumo Energético y Gráficos
**Objetivo:** Módulo completo de energía con visualizaciones

**Entregables:**
- Modelos: `homes`, `energy_readings`, `saving_goals`
- Módulo `energy` backend completo
- Simulador de datos IoT (`energy/simulator.py`)
- Endpoints: lecturas, consumo diario/mensual/anual, comparativas, metas, export PDF/CSV
- Vista frontend `energy.html`
- JS modules: `energy-charts.js`, `charts.js`
- Gráficos Chart.js: línea (consumo temporal), barra (comparativas), donut (distribución)
- Exportación PDF backend (ReportLab)

**Validación:**
- Simulador genera lecturas cada X minutos
- Gráficos renderizan correctamente
- Comparativas muestran datos precisos
- Metas de ahorro se crean y rastrean
- PDF exporta con datos correctos

---

### Fase 7: Dispositivos y Realtime
**Objetivo:** Gestión de dispositivos IoT con estado en tiempo real

**Entregables:**
- Modelo `devices`
- Módulo `devices` backend completo
- Endpoints: CRUD dispositivos, control, estado, historial
- Vista frontend `devices.html`
- Componente `device-card.js`
- JS module: `devices-manager.js`
- Eventos WebSocket para estado en tiempo real
- Simulación de cambios de estado

**Validación:**
- Dispositivos se registran correctamente
- Control (on/off) funciona
- Estado se actualiza en tiempo real vía WebSocket
- Historial de estados se registra
- Tarjetas dispositivos muestran estado actual

---

### Fase 8: Alertas y Notificaciones Multicanal
**Objetivo:** Sistema completo de alertas y notificaciones

**Entregables:**
- Modelos: `alerts`, `alert_rules`, `notifications`
- Módulo `alerts` backend (motor de evaluación de reglas)
- Módulo `notifications` backend (email, SMS, WhatsApp, WebSocket)
- Endpoints: CRUD alertas, reglas, preferencias notificaciones
- Integración SendGrid/Gmail, Twilio
- Vista frontend `alerts.html`
- Componente `alert-card.js`
- JS module: `alerts-manager.js`
- Notificaciones realtime por WebSocket
- Sistema toast para notificaciones UI

**Validación:**
- Reglas se evalúan correctamente
- Alertas se generan automáticamente
- Emails se envían correctamente
- SMS/WhatsApp funcionan (según configuración Twilio)
- Notificaciones push aparecen en tiempo real
- Preferencias de canal se respetan

---

### Fase 9: Recomendaciones y Gamificación
**Objetivo:** Motor de recomendaciones y sistema de logros

**Entregables:**
- Modelos: `recommendations`, `achievements`, `user_achievements`
- Módulo `recommendations` backend (motor de generación)
- Módulo `gamification` backend (motor de evaluación logros)
- Endpoints: recomendaciones, logros, leaderboard, progreso
- Vista frontend `recommendations.html`, `achievements.html`
- Componentes: `recommendation-card.js`
- JS module: `gamification.js`
- Definición de logros predefinidos
- Algoritmo de recomendaciones basado en patrones

**Validación:**
- Recomendaciones se generan según consumo
- Logros se desbloquean automáticamente
- Progreso se rastrea correctamente
- Leaderboard muestra rankings
- UI muestra recomendaciones aplicables

---

### Fase 10: Pagos y Facturación
**Objetivo:** Integración completa con Stripe

**Entregables:**
- Modelos: `payments`, `invoices`, `subscriptions`
- Módulo `payments` backend (Stripe adapter, webhooks)
- Endpoints: checkout, métodos pago, historial, facturas, suscripciones
- Vista frontend `payments.html`
- JS module: `payments.js`
- Integración Stripe.js
- Generación automática facturas PDF
- Webhook handlers Stripe

**Validación:**
- Checkout crea sesión Stripe correctamente
- Pago se procesa exitosamente
- Webhooks reciben y procesan eventos
- Facturas se generan automáticamente
- Suscripciones se crean y rastrean
- Historial de pagos completo

---

### Fase 11: Asistente IA y Proveedores
**Objetivo:** Chat conversacional con IA multi-provider

**Entregables:**
- Modelos: `ai_conversations`, `ai_messages`
- Módulo `ai` backend (capa abstracta, factory, providers)
- Implementación `OpenAIProvider`
- Endpoints: chat, conversaciones, providers
- Vista frontend `ai-assistant.html`
- JS module: `assistant-chat.js`
- Chat UI interactivo
- Streaming de respuestas (opcional)
- Contexto de conversación persistente

**Validación:**
- Chat funciona con OpenAI
- Conversaciones se guardan correctamente
- Respuestas son coherentes y contextuales
- Factory permite cambiar provider
- UI de chat es responsive y fluida

---

### Fase 12: Reportes, Backups y Offline Básico
**Objetivo:** Generación de reportes, backup automático y soporte offline básico

**Entregables:**
- Módulo `reports` backend (generación PDF personalizada)
- Sistema de backup automático (scheduler)
- Script manual de backup
- Endpoints: reportes, templates, backups (admin)
- Vista frontend `history.html`
- JS module: `offline-sync.js`
- Cache básico frontend (LocalStorage)
- Cola de acciones offline
- Service Worker básico (opcional)

**Validación:**
- Reportes PDF se generan correctamente
- Backup automático se ejecuta según schedule
- Backup manual funciona
- Restauración de backup exitosa
- Modo offline cache datos básicos
- Acciones offline se sincronizan al reconectar

---

### Fase 13: Panel Admin y Sistema
**Objetivo:** Herramientas de administración

**Entregables:**
- Módulo `admin` backend completo
- Endpoints: gestión usuarios, estadísticas, logs, eventos, backups
- Vista frontend `admin.html` (solo accesible con rol admin)
- Protección por rol en todas las rutas admin
- Dashboard de estadísticas sistema
- Visor de logs
- Gestión de usuarios (activar, desactivar, resetear contraseña)

**Validación:**
- Solo usuarios admin acceden a panel
- Estadísticas muestran datos correctos
- Logs se visualizan correctamente
- Gestión de usuarios funciona
- Backups se listan y restauran

---

### Fase 14: Endurecimiento, Observabilidad y Despliegue
**Objetivo:** Preparar para producción

**Entregables:**
- Tests unitarios módulos críticos
- Tests de integración flujos principales
- Tests API endpoints
- Configuración logging producción
- Configuración WSGI/ASGI producción
- Dockerfiles (opcional)
- Guía de despliegue (`docs/deployment.md`)
- Variables de entorno producción documentadas
- Rate limiting exhaustivo
- Monitoreo básico (health checks, métricas)
- HTTPS enforcement
- Security headers (CSP, HSTS, etc.)

**Validación:**
- Tests pasan con cobertura > 80%
- Aplicación corre en entorno producción
- Performance aceptable bajo carga
- Logs se envían correctamente
- Monitoreo funciona
- Security scan sin vulnerabilidades críticas

---

## Referencias y Documentación Adicional

### Documentos Complementarios
- **`docs/api-endpoints.md`**: Especificación OpenAPI/Swagger de todos los endpoints
- **`docs/database-schema.md`**: Esquema detallado con ejemplos de queries
- **`docs/deployment.md`**: Guía paso a paso para despliegue en producción
- **`docs/diagrams/`**: Diagramas Mermaid de flujos, arquitectura y datos

### Recursos Externos
- [Flask Documentation](https://flask.palletsprojects.com/)
- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [Marshmallow Documentation](https://marshmallow.readthedocs.io/)
- [Flask-SocketIO Documentation](https://flask-socketio.readthedocs.io/)
- [Stripe API Reference](https://stripe.com/docs/api)
- [OpenAI API Reference](https://platform.openai.com/docs/api-reference)
- [Twilio Documentation](https://www.twilio.com/docs)
- [Chart.js Documentation](https://www.chartjs.org/docs/)

---

## Notas Finales

Este documento representa la arquitectura **definitiva y completa** de Nexergy. Toda decisión técnica está justificada y alineada con los objetivos del proyecto. La estructura es exhaustiva y no requiere modificaciones estructurales posteriores.

La implementación debe seguir las fases en orden, validando cada entregable antes de avanzar. El resultado será un sistema robusto, escalable y mantenible que cumple todos los requisitos funcionales especificados.

**Última actualización:** 2026-04-21  
**Versión:** 1.0  
**Estado:** Aprobado para implementación

import os
from flask import Flask, send_from_directory
from config import config
from app.extensions import db, migrate, jwt, bcrypt, socketio, cors, limiter, ma


def create_app(config_name=None):
    if config_name is None:
        config_name = os.getenv('FLASK_ENV', 'development')

    app = Flask(__name__, static_folder=None)
    app.config.from_object(config[config_name])

    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    bcrypt.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})
    limiter.init_app(app)
    ma.init_app(app)
    socketio.init_app(app, cors_allowed_origins="*", async_mode='eventlet')

    # Register blueprints
    from app.routes import register_blueprints
    register_blueprints(app)

    # Register error handlers
    from app.core.errors import register_error_handlers
    register_error_handlers(app)

    # JWT callbacks
    from app.core.jwt_helpers import register_jwt_callbacks
    register_jwt_callbacks(jwt)

    # Serve frontend
    frontend_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'frontend')

    @app.route('/')
    def serve_landing():
        return send_from_directory(frontend_dir, 'index.html')

    @app.route('/<path:filename>')
    def serve_frontend(filename):
        try:
            return send_from_directory(frontend_dir, filename)
        except Exception:
            return send_from_directory(frontend_dir, 'index.html')

    return app

from app.extensions import ma
from marshmallow import fields


class DashboardStatsSchema(ma.Schema):
    period = fields.String(load_default='today')

from app.core.base_repository import BaseRepository
from app.models import Home, Device, EnergyReading, Alert, Recommendation
from sqlalchemy import and_, desc
from datetime import datetime, timedelta


class DashboardRepository(BaseRepository):
    """Repository para operaciones del dashboard"""

    def get_user_homes(self, user_id: int):
        """Obtiene todas las viviendas del usuario"""
        return Home.query.filter_by(user_id=user_id).all()

    def get_home_stats(self, home_id: int):
        """Obtiene estadísticas del hogar"""
        devices = Device.query.filter_by(home_id=home_id).all()
        online_devices = [d for d in devices if d.status == 'online']
        
        return {
            'total_devices': len(devices),
            'online_devices': len(online_devices),
            'offline_devices': len(devices) - len(online_devices)
        }

    def get_energy_overview(self, home_id: int):
        """Obtiene resumen de consumo energético"""
        today = datetime.utcnow().date()
        readings_today = EnergyReading.query.filter(
            and_(
                EnergyReading.home_id == home_id,
                EnergyReading.timestamp >= datetime.combine(today, datetime.min.time())
            )
        ).all()
        
        yesterday = today - timedelta(days=1)
        readings_yesterday = EnergyReading.query.filter(
            and_(
                EnergyReading.home_id == home_id,
                EnergyReading.timestamp >= datetime.combine(yesterday, datetime.min.time()),
                EnergyReading.timestamp < datetime.combine(today, datetime.min.time())
            )
        ).all()
        
        return {
            'today_kwh': sum(r.kwh for r in readings_today) if readings_today else 0,
            'yesterday_kwh': sum(r.kwh for r in readings_yesterday) if readings_yesterday else 0
        }

    def get_recent_alerts(self, user_id: int, limit: int = 5):
        """Obtiene alertas recientes del usuario"""
        return Alert.query.filter_by(user_id=user_id).order_by(
            desc(Alert.created_at)
        ).limit(limit).all()

    def get_recent_recommendations(self, user_id: int, limit: int = 5):
        """Obtiene recomendaciones recientes"""
        return Recommendation.query.filter_by(user_id=user_id).order_by(
            desc(Recommendation.created_at)
        ).limit(limit).all()

    def get_unread_alerts(self, user_id: int):
        """Obtiene alertas no leídas"""
        return Alert.query.filter(
            and_(
                Alert.user_id == user_id,
                Alert.is_read == False
            )
        ).all()

from datetime import datetime, timedelta
from sqlalchemy import func
import requests
from flask import current_app
from app.extensions import db
from app.models.user import User
from app.models.home import Home
from app.models.device import Device
from app.models.energy_reading import EnergyReading
from app.models.alert import Alert
from app.models.saving_goal import SavingGoal
from app.models.achievement import Achievement
from app.models.user_achievement import UserAchievement


class DashboardService:

    @staticmethod
    def get_overview(user_id):
        user = User.query.get(user_id)
        if not user:
            return None, 'User not found'

        homes = Home.query.filter_by(user_id=user_id).all()
        total_devices = sum(Device.query.filter_by(home_id=h.id).count() for h in homes)
        online_devices = sum(Device.query.filter_by(home_id=h.id, status='online').count() for h in homes)
        unread_alerts = Alert.query.filter_by(user_id=user_id, is_read=False).count()
        active_goals = SavingGoal.query.filter_by(user_id=user_id, status='active').count()
        achievements_count = UserAchievement.query.filter_by(user_id=user_id).count()

        today = datetime.utcnow().date()
        today_start = datetime.combine(today, datetime.min.time())
        home_ids = [h.id for h in homes]
        today_consumption = 0
        if home_ids:
            result = db.session.query(func.sum(EnergyReading.kwh)).filter(
                EnergyReading.home_id.in_(home_ids),
                EnergyReading.timestamp >= today_start
            ).scalar()
            today_consumption = float(result) if result else 0

        profile_data = {}
        if user.profile:
            profile_data = {
                'first_name': user.profile.first_name,
                'last_name': user.profile.last_name,
                'avatar': user.profile.avatar
            }

        return {
            'user': {**user.to_dict(), 'profile': profile_data},
            'stats': {
                'total_homes': len(homes),
                'total_devices': total_devices,
                'online_devices': online_devices,
                'unread_alerts': unread_alerts,
                'active_goals': active_goals,
                'achievements': achievements_count,
                'today_consumption_kwh': round(today_consumption, 2)
            }
        }, None

    @staticmethod
    def get_stats(user_id, period='today'):
        homes = Home.query.filter_by(user_id=user_id).all()
        home_ids = [h.id for h in homes]
        if not home_ids:
            return {'consumption': [], 'total_kwh': 0}, None

        now = datetime.utcnow()
        if period == 'today':
            start = datetime.combine(now.date(), datetime.min.time())
        elif period == 'week':
            start = now - timedelta(days=7)
        elif period == 'month':
            start = now - timedelta(days=30)
        elif period == 'year':
            start = now - timedelta(days=365)
        else:
            start = datetime.combine(now.date(), datetime.min.time())

        readings = EnergyReading.query.filter(
            EnergyReading.home_id.in_(home_ids),
            EnergyReading.timestamp >= start
        ).order_by(EnergyReading.timestamp).all()

        total = sum(float(r.kwh) for r in readings)

        return {
            'consumption': [r.to_dict() for r in readings[-100:]],
            'total_kwh': round(total, 2),
            'period': period,
            'start': start.isoformat(),
            'end': now.isoformat()
        }, None

    @staticmethod
    def get_weather(lat, lon):
        api_key = current_app.config.get('OPENWEATHER_API_KEY')
        if not api_key:
            return {'message': 'Weather API not configured'}, None
        try:
            url = f'https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={api_key}&units=metric&lang=es'
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                data = response.json()
                return {
                    'temp': data['main']['temp'],
                    'feels_like': data['main']['feels_like'],
                    'humidity': data['main']['humidity'],
                    'description': data['weather'][0]['description'] if data.get('weather') else '',
                    'icon': data['weather'][0]['icon'] if data.get('weather') else '',
                    'city': data.get('name', '')
                }, None
            return {'message': 'Unable to fetch weather'}, None
        except Exception:
            return {'message': 'Weather service unavailable'}, None

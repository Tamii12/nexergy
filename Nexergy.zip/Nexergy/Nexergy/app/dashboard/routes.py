from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.dashboard.service import DashboardService

dashboard_bp = Blueprint('dashboard', __name__)


@dashboard_bp.route('/overview', methods=['GET'])
@jwt_required()
def overview():
    user_id = int(get_jwt_identity())
    data, error = DashboardService.get_overview(user_id)
    if error:
        return jsonify({'error': error}), 404
    return jsonify(data), 200


@dashboard_bp.route('/stats', methods=['GET'])
@jwt_required()
def stats():
    user_id = int(get_jwt_identity())
    period = request.args.get('period', 'today')
    data, error = DashboardService.get_stats(user_id, period)
    if error:
        return jsonify({'error': error}), 400
    return jsonify(data), 200


@dashboard_bp.route('/weather', methods=['GET'])
@jwt_required()
def weather():
    lat = request.args.get('lat', type=float)
    lon = request.args.get('lon', type=float)
    if lat is None or lon is None:
        return jsonify({'error': 'lat and lon parameters required'}), 422
    data, _ = DashboardService.get_weather(lat, lon)
    return jsonify(data), 200


@dashboard_bp.route('/carousel', methods=['GET'])
@jwt_required()
def carousel():
    images = [
        {'id': 1, 'src': '/assets/img/carousel/energy-saving.jpg', 'title': 'Ahorra Energía', 'description': 'Descubre cómo reducir tu consumo'},
        {'id': 2, 'src': '/assets/img/carousel/smart-home.jpg', 'title': 'Hogar Inteligente', 'description': 'Controla todos tus dispositivos'},
        {'id': 3, 'src': '/assets/img/carousel/green-energy.jpg', 'title': 'Energía Verde', 'description': 'Contribuye al medio ambiente'}
    ]
    return jsonify({'images': images}), 200

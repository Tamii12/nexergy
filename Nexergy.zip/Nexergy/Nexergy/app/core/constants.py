# User Roles
ROLE_USER = 'user'
ROLE_ADMIN = 'admin'

# Alert Severities
SEVERITY_INFO = 'info'
SEVERITY_WARNING = 'warning'
SEVERITY_CRITICAL = 'critical'

# Device Status
DEVICE_ONLINE = 'online'
DEVICE_OFFLINE = 'offline'
DEVICE_ERROR = 'error'

# Device Types
DEVICE_TYPES = [
    'smart_meter', 'light', 'ac', 'heater', 'refrigerator',
    'washer', 'dryer', 'oven', 'tv', 'computer', 'fan',
    'water_heater', 'solar_panel', 'battery', 'ev_charger', 'other'
]

# Notification Channels
CHANNEL_EMAIL = 'email'
CHANNEL_SMS = 'sms'
CHANNEL_WHATSAPP = 'whatsapp'
CHANNEL_PUSH = 'push'

# Payment Status
PAYMENT_PENDING = 'pending'
PAYMENT_COMPLETED = 'completed'
PAYMENT_FAILED = 'failed'
PAYMENT_REFUNDED = 'refunded'

# Subscription Plans
PLAN_BASIC = 'basic'
PLAN_PREMIUM = 'premium'
PLAN_ENTERPRISE = 'enterprise'

# AI Roles
AI_ROLE_USER = 'user'
AI_ROLE_ASSISTANT = 'assistant'
AI_ROLE_SYSTEM = 'system'

# Saving Goal Status
GOAL_ACTIVE = 'active'
GOAL_ACHIEVED = 'achieved'
GOAL_FAILED = 'failed'

# Token Types
TOKEN_ACCESS = 'access'
TOKEN_REFRESH = 'refresh'

# Pagination
DEFAULT_PAGE_SIZE = 20
MAX_PAGE_SIZE = 100

from functools import wraps
from flask import jsonify
from flask_jwt_extended import verify_jwt_in_request, get_jwt


def role_required(role_name):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            verify_jwt_in_request()
            claims = get_jwt()
            roles = claims.get('roles', [])
            if role_name not in roles:
                return jsonify({'error': 'Forbidden', 'message': f'Role "{role_name}" required'}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        verify_jwt_in_request()
        claims = get_jwt()
        roles = claims.get('roles', [])
        if 'admin' not in roles:
            return jsonify({'error': 'Forbidden', 'message': 'Admin access required'}), 403
        return fn(*args, **kwargs)
    return wrapper

from flask import jsonify
from app.extensions import db


def register_jwt_callbacks(jwt):
    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return jsonify({'error': 'Token Expired', 'message': 'The token has expired'}), 401

    @jwt.invalid_token_loader
    def invalid_token_callback(error):
        return jsonify({'error': 'Invalid Token', 'message': 'Token verification failed'}), 401

    @jwt.unauthorized_loader
    def missing_token_callback(error):
        return jsonify({'error': 'Missing Token', 'message': 'Authorization token is required'}), 401

    @jwt.revoked_token_loader
    def revoked_token_callback(jwt_header, jwt_payload):
        return jsonify({'error': 'Revoked Token', 'message': 'Token has been revoked'}), 401

    @jwt.token_in_blocklist_loader
    def check_if_token_revoked(jwt_header, jwt_payload):
        from app.models.token_blacklist import TokenBlacklist
        jti = jwt_payload['jti']
        token = db.session.query(TokenBlacklist).filter_by(jti=jti).first()
        return token is not None

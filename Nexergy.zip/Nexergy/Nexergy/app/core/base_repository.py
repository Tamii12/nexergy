from app.extensions import db


class BaseRepository:
    model = None

    def get_by_id(self, id):
        return self.model.query.get(id)

    def get_all(self, page=1, per_page=20, **filters):
        query = self.model.query
        for key, value in filters.items():
            if hasattr(self.model, key) and value is not None:
                query = query.filter(getattr(self.model, key) == value)
        return query.paginate(page=page, per_page=per_page, error_out=False)

    def create(self, data):
        instance = self.model(**data)
        db.session.add(instance)
        db.session.commit()
        return instance

    def update(self, id, data):
        instance = self.get_by_id(id)
        if instance:
            for key, value in data.items():
                if hasattr(instance, key):
                    setattr(instance, key, value)
            db.session.commit()
        return instance

    def delete(self, id):
        instance = self.get_by_id(id)
        if instance:
            db.session.delete(instance)
            db.session.commit()
            return True
        return False

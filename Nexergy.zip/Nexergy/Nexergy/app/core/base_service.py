class BaseService:
    def __init__(self, repository):
        self.repository = repository

    def get_by_id(self, id):
        return self.repository.get_by_id(id)

    def get_all(self, page=1, per_page=20, **filters):
        return self.repository.get_all(page=page, per_page=per_page, **filters)

    def create(self, data):
        return self.repository.create(data)

    def update(self, id, data):
        return self.repository.update(id, data)

    def delete(self, id):
        return self.repository.delete(id)

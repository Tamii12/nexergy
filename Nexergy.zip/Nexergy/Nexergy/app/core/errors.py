from flask import jsonify
from marshmallow import ValidationError


def register_error_handlers(app):
    @app.errorhandler(400)
    def bad_request(e):
        return jsonify({'error': 'Bad Request', 'message': str(e)}), 400

    @app.errorhandler(401)
    def unauthorized(e):
        return jsonify({'error': 'Unauthorized', 'message': 'Authentication required'}), 401

    @app.errorhandler(403)
    def forbidden(e):
        return jsonify({'error': 'Forbidden', 'message': 'You do not have permission to access this resource'}), 403

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({'error': 'Not Found', 'message': 'Resource not found'}), 404

    @app.errorhandler(405)
    def method_not_allowed(e):
        return jsonify({'error': 'Method Not Allowed', 'message': str(e)}), 405

    @app.errorhandler(422)
    def unprocessable(e):
        return jsonify({'error': 'Unprocessable Entity', 'message': str(e)}), 422

    @app.errorhandler(429)
    def too_many_requests(e):
        return jsonify({'error': 'Too Many Requests', 'message': 'Rate limit exceeded. Try again later.'}), 429

    @app.errorhandler(500)
    def internal_error(e):
        return jsonify({'error': 'Internal Server Error', 'message': 'An unexpected error occurred'}), 500

    @app.errorhandler(ValidationError)
    def validation_error(e):
        return jsonify({'error': 'Validation Error', 'message': e.messages}), 422

from marshmallow import ValidationError
from app.core.security import validate_email, validate_password_strength, validate_phone


def validate_email_field(email):
    if not validate_email(email):
        raise ValidationError('Invalid email address')


def validate_password_field(password):
    errors = validate_password_strength(password)
    if errors:
        raise ValidationError(errors)


def validate_phone_field(phone):
    if phone and not validate_phone(phone):
        raise ValidationError('Invalid phone number format')


def validate_not_empty(value):
    if not value or not value.strip():
        raise ValidationError('Field cannot be empty')

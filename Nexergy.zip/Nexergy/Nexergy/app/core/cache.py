import json
from datetime import datetime


class MemoryCache:
    def __init__(self):
        self._cache = {}

    def get(self, key):
        item = self._cache.get(key)
        if item and item['expires_at'] > datetime.utcnow().timestamp():
            return item['value']
        elif item:
            del self._cache[key]
        return None

    def set(self, key, value, ttl=300):
        self._cache[key] = {
            'value': value,
            'expires_at': datetime.utcnow().timestamp() + ttl
        }

    def delete(self, key):
        self._cache.pop(key, None)

    def clear(self):
        self._cache.clear()


cache = MemoryCache()

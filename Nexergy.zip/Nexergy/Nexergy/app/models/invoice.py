from datetime import datetime
from app.extensions import db


class Invoice(db.Model):
    __tablename__ = 'invoices'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    payment_id = db.Column(db.Integer, db.ForeignKey('payments.id', ondelete='SET NULL'), nullable=True)
    invoice_number = db.Column(db.String(50), unique=True, nullable=False)
    pdf_url = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_inv_user', 'user_id', db.desc('created_at')),
    )

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id, 'payment_id': self.payment_id,
            'invoice_number': self.invoice_number, 'pdf_url': self.pdf_url,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

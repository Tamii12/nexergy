from datetime import datetime
from app.extensions import db


class Alert(db.Model):
    __tablename__ = 'alerts'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    rule_id = db.Column(db.Integer, db.ForeignKey('alert_rules.id', ondelete='SET NULL'), nullable=True)
    type = db.Column(db.String(50), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    severity = db.Column(db.String(20), default='info')
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_alerts_user_read', 'user_id', 'is_read', db.desc('created_at')),
        db.Index('idx_alerts_severity', 'severity'),
    )

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id, 'rule_id': self.rule_id,
            'type': self.type, 'title': self.title, 'message': self.message,
            'severity': self.severity, 'is_read': self.is_read,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

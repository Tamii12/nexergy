from datetime import datetime
from app.extensions import db


class Subscription(db.Model):
    __tablename__ = 'subscriptions'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    plan = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='active')
    stripe_subscription_id = db.Column(db.String(255), nullable=True, index=True)
    current_period_end = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_sub_user_status', 'user_id', 'status'),
    )

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id, 'plan': self.plan,
            'status': self.status, 'stripe_subscription_id': self.stripe_subscription_id,
            'current_period_end': self.current_period_end.isoformat() if self.current_period_end else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

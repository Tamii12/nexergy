from datetime import datetime
from app.extensions import db


class EnergyReading(db.Model):
    __tablename__ = 'energy_readings'

    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    home_id = db.Column(db.Integer, db.ForeignKey('homes.id', ondelete='CASCADE'), nullable=False)
    device_id = db.Column(db.Integer, db.ForeignKey('devices.id', ondelete='SET NULL'), nullable=True)
    timestamp = db.Column(db.DateTime, nullable=False, index=True)
    kwh = db.Column(db.Numeric(10, 4), nullable=False)
    voltage = db.Column(db.Numeric(6, 2), nullable=True)
    current = db.Column(db.Numeric(6, 2), nullable=True)
    power_factor = db.Column(db.Numeric(4, 3), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_readings_home_time', 'home_id', db.desc('timestamp')),
        db.Index('idx_readings_device_time', 'device_id', db.desc('timestamp')),
    )

    def to_dict(self):
        return {
            'id': self.id, 'home_id': self.home_id, 'device_id': self.device_id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'kwh': float(self.kwh), 'voltage': float(self.voltage) if self.voltage else None,
            'current': float(self.current) if self.current else None,
            'power_factor': float(self.power_factor) if self.power_factor else None
        }

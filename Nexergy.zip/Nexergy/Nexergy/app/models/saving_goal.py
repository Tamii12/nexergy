from datetime import datetime
from app.extensions import db


class SavingGoal(db.Model):
    __tablename__ = 'saving_goals'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    target_kwh = db.Column(db.Numeric(10, 2), nullable=False)
    target_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), default='active')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_goals_user_status', 'user_id', 'status'),
    )

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id,
            'target_kwh': float(self.target_kwh), 'target_date': self.target_date.isoformat(),
            'status': self.status, 'created_at': self.created_at.isoformat() if self.created_at else None
        }

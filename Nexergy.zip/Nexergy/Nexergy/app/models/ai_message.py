from datetime import datetime
from app.extensions import db


class AIMessage(db.Model):
    __tablename__ = 'ai_messages'

    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey('ai_conversations.id', ondelete='CASCADE'), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_msg_conv_time', 'conversation_id', 'timestamp'),
    )

    def to_dict(self):
        return {
            'id': self.id, 'conversation_id': self.conversation_id,
            'role': self.role, 'content': self.content,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }

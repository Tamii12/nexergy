from datetime import datetime
from app.extensions import db


class Notification(db.Model):
    __tablename__ = 'notifications'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    channel = db.Column(db.String(20), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    sent_at = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), default='pending')
    metadata_json = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_notif_user_status', 'user_id', 'status', db.desc('created_at')),
        db.Index('idx_notif_channel', 'channel', 'status'),
    )

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id, 'channel': self.channel,
            'title': self.title, 'message': self.message,
            'sent_at': self.sent_at.isoformat() if self.sent_at else None,
            'status': self.status, 'metadata': self.metadata_json,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

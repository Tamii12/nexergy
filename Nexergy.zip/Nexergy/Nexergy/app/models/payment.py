from datetime import datetime
from app.extensions import db


class Payment(db.Model):
    __tablename__ = 'payments'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    currency = db.Column(db.String(3), default='USD')
    status = db.Column(db.String(20), default='pending')
    stripe_payment_id = db.Column(db.String(255), nullable=True, index=True)
    metadata_json = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    invoice = db.relationship('Invoice', backref='payment', uselist=False)

    __table_args__ = (
        db.Index('idx_pay_user', 'user_id', db.desc('created_at')),
        db.Index('idx_pay_status', 'status'),
    )

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id,
            'amount': float(self.amount), 'currency': self.currency,
            'status': self.status, 'stripe_payment_id': self.stripe_payment_id,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

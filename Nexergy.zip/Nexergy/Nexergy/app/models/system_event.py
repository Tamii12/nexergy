from datetime import datetime
from app.extensions import db


class SystemEvent(db.Model):
    __tablename__ = 'system_events'

    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    type = db.Column(db.String(50), nullable=False)
    payload_json = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_event_type_time', 'type', db.desc('created_at')),
    )

    def to_dict(self):
        return {
            'id': self.id, 'type': self.type,
            'payload': self.payload_json,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

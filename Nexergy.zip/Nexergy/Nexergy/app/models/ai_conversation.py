from datetime import datetime
from app.extensions import db


class AIConversation(db.Model):
    __tablename__ = 'ai_conversations'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    title = db.Column(db.String(200), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    messages = db.relationship('AIMessage', backref='conversation', lazy='dynamic', cascade='all, delete-orphan', order_by='AIMessage.timestamp')

    __table_args__ = (
        db.Index('idx_conv_user', 'user_id', db.desc('updated_at')),
    )

    def to_dict(self, include_messages=False):
        data = {
            'id': self.id, 'user_id': self.user_id, 'title': self.title,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        if include_messages:
            data['messages'] = [m.to_dict() for m in self.messages]
        return data

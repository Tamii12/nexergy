from datetime import datetime
from app.extensions import db


class Recommendation(db.Model):
    __tablename__ = 'recommendations'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    type = db.Column(db.String(50), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    impact_kwh = db.Column(db.Numeric(8, 2), nullable=True)
    is_applied = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_rec_user_applied', 'user_id', 'is_applied', db.desc('created_at')),
        db.Index('idx_rec_type', 'type'),
    )

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id, 'type': self.type,
            'title': self.title, 'description': self.description,
            'impact_kwh': float(self.impact_kwh) if self.impact_kwh else None,
            'is_applied': self.is_applied,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

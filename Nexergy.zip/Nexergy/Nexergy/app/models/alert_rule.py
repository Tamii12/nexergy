from datetime import datetime
from app.extensions import db


class AlertRule(db.Model):
    __tablename__ = 'alert_rules'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    condition_json = db.Column(db.JSON, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    alerts = db.relationship('Alert', backref='rule', lazy='dynamic')

    __table_args__ = (
        db.Index('idx_rules_user_active', 'user_id', 'is_active'),
    )

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id, 'name': self.name,
            'condition': self.condition_json, 'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

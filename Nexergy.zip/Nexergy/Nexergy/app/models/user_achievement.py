from datetime import datetime
from app.extensions import db


class UserAchievement(db.Model):
    __tablename__ = 'user_achievements'

    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    achievement_id = db.Column(db.Integer, db.ForeignKey('achievements.id', ondelete='CASCADE'), primary_key=True)
    unlocked_at = db.Column(db.DateTime, default=datetime.utcnow)
    progress = db.Column(db.Numeric(5, 2), default=0.00)

    achievement = db.relationship('Achievement', backref='user_achievements')
    user = db.relationship('User', backref='achievements_earned')

    __table_args__ = (
        db.Index('idx_ua_user_unlock', 'user_id', db.desc('unlocked_at')),
    )

    def to_dict(self):
        return {
            'user_id': self.user_id, 'achievement_id': self.achievement_id,
            'unlocked_at': self.unlocked_at.isoformat() if self.unlocked_at else None,
            'progress': float(self.progress),
            'achievement': self.achievement.to_dict() if self.achievement else None
        }

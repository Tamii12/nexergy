from datetime import datetime
from app.extensions import db


class Device(db.Model):
    __tablename__ = 'devices'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    home_id = db.Column(db.Integer, db.ForeignKey('homes.id', ondelete='CASCADE'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default='offline')
    last_reading = db.Column(db.DateTime, nullable=True)
    metadata_json = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    energy_readings = db.relationship('EnergyReading', backref='device', lazy='dynamic')

    __table_args__ = (
        db.Index('idx_devices_home_status', 'home_id', 'status'),
        db.Index('idx_devices_type', 'type'),
    )

    def to_dict(self):
        return {
            'id': self.id, 'home_id': self.home_id, 'name': self.name,
            'type': self.type, 'status': self.status,
            'last_reading': self.last_reading.isoformat() if self.last_reading else None,
            'metadata': self.metadata_json,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

from datetime import datetime
from app.extensions import db


class Home(db.Model):
    __tablename__ = 'homes'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(255), nullable=True)
    city = db.Column(db.String(100), nullable=True)
    country = db.Column(db.String(100), nullable=True)
    lat = db.Column(db.Numeric(10, 8), nullable=True)
    lon = db.Column(db.Numeric(11, 8), nullable=True)
    timezone = db.Column(db.String(50), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    devices = db.relationship('Device', backref='home', lazy='dynamic', cascade='all, delete-orphan')
    energy_readings = db.relationship('EnergyReading', backref='home', lazy='dynamic', cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id, 'name': self.name,
            'address': self.address, 'city': self.city, 'country': self.country,
            'lat': float(self.lat) if self.lat else None,
            'lon': float(self.lon) if self.lon else None,
            'timezone': self.timezone,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

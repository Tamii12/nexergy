from datetime import datetime
from app.extensions import db


class ActivityLog(db.Model):
    __tablename__ = 'activity_logs'

    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    action = db.Column(db.String(100), nullable=False)
    resource = db.Column(db.String(100), nullable=True)
    ip = db.Column(db.String(45), nullable=True)
    user_agent = db.Column(db.String(255), nullable=True)
    metadata_json = db.Column(db.JSON, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    __table_args__ = (
        db.Index('idx_log_user_time', 'user_id', db.desc('timestamp')),
        db.Index('idx_log_action', 'action', db.desc('timestamp')),
    )

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id, 'action': self.action,
            'resource': self.resource, 'ip': self.ip,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }

from app.extensions import ma
from marshmallow import fields, validate


class UpdateProfileSchema(ma.Schema):
    first_name = fields.String(validate=validate.Length(min=2, max=100))
    last_name = fields.String(validate=validate.Length(min=2, max=100))
    phone = fields.String(validate=validate.Length(max=20))


class UpdateSettingsSchema(ma.Schema):
    preferences = fields.Dict()

from app.extensions import db
from app.models.user import User
from app.models.user_profile import UserProfile


class UserService:

    @staticmethod
    def get_profile(user_id):
        user = User.query.get(user_id)
        if not user:
            return None, 'User not found'
        data = user.to_dict()
        if user.profile:
            data['profile'] = user.profile.to_dict()
        return data, None

    @staticmethod
    def update_profile(user_id, data):
        user = User.query.get(user_id)
        if not user:
            return None, 'User not found'
        if not user.profile:
            user.profile = UserProfile(user_id=user_id)
        for key in ('first_name', 'last_name', 'phone'):
            if key in data:
                setattr(user.profile, key, data[key])
        db.session.commit()
        return user.profile.to_dict(), None

    @staticmethod
    def get_settings(user_id):
        user = User.query.get(user_id)
        if not user or not user.profile:
            return {'preferences': {}}, None
        return {'preferences': user.profile.preferences_json or {}}, None

    @staticmethod
    def update_settings(user_id, preferences):
        user = User.query.get(user_id)
        if not user:
            return None, 'User not found'
        if not user.profile:
            user.profile = UserProfile(user_id=user_id)
        user.profile.preferences_json = preferences
        db.session.commit()
        return {'preferences': user.profile.preferences_json}, None

    @staticmethod
    def update_avatar(user_id, avatar_url):
        user = User.query.get(user_id)
        if not user:
            return None, 'User not found'
        if not user.profile:
            user.profile = UserProfile(user_id=user_id)
        user.profile.avatar = avatar_url
        db.session.commit()
        return {'avatar': user.profile.avatar}, None

    @staticmethod
    def delete_avatar(user_id):
        user = User.query.get(user_id)
        if not user or not user.profile:
            return False, 'User not found'
        user.profile.avatar = None
        db.session.commit()
        return True, None

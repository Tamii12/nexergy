from app.core.base_repository import BaseRepository
from app.models import User, UserProfile
from sqlalchemy import and_


class UsersRepository(BaseRepository):
    """Repository para operaciones de usuarios"""

    def get_user_profile(self, user_id: int):
        """Obtiene el perfil del usuario"""
        return UserProfile.query.filter_by(user_id=user_id).first()

    def create_user_profile(self, user_id: int, **data):
        """Crea perfil de usuario"""
        profile = UserProfile(user_id=user_id, **data)
        self.db.session.add(profile)
        self.db.session.commit()
        return profile

    def update_user_profile(self, user_id: int, **data):
        """Actualiza perfil de usuario"""
        profile = UserProfile.query.filter_by(user_id=user_id).first()
        if profile:
            for key, value in data.items():
                if hasattr(profile, key):
                    setattr(profile, key, value)
            self.db.session.commit()
        return profile

    def get_user_settings(self, user_id: int):
        """Obtiene configuraciones del usuario"""
        profile = UserProfile.query.filter_by(user_id=user_id).first()
        if profile and profile.preferences_json:
            return profile.preferences_json
        return {}

    def update_user_settings(self, user_id: int, settings: dict):
        """Actualiza configuraciones del usuario"""
        profile = UserProfile.query.filter_by(user_id=user_id).first()
        if profile:
            profile.preferences_json = settings
            self.db.session.commit()
        return profile

    def update_user_avatar(self, user_id: int, avatar_url: str):
        """Actualiza avatar del usuario"""
        profile = UserProfile.query.filter_by(user_id=user_id).first()
        if profile:
            profile.avatar = avatar_url
            self.db.session.commit()
        return profile

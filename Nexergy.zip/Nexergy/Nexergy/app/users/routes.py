from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.users.service import UserService
from app.users.schemas import UpdateProfileSchema, UpdateSettingsSchema

users_bp = Blueprint('users', __name__)


@users_bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    user_id = int(get_jwt_identity())
    data, error = UserService.get_profile(user_id)
    if error:
        return jsonify({'error': error}), 404
    return jsonify(data), 200


@users_bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    schema = UpdateProfileSchema()
    errors = schema.validate(request.json or {})
    if errors:
        return jsonify({'error': 'Validation Error', 'message': errors}), 422
    user_id = int(get_jwt_identity())
    data, error = UserService.update_profile(user_id, schema.load(request.json))
    if error:
        return jsonify({'error': error}), 404
    return jsonify(data), 200


@users_bp.route('/settings', methods=['GET'])
@jwt_required()
def get_settings():
    user_id = int(get_jwt_identity())
    data, _ = UserService.get_settings(user_id)
    return jsonify(data), 200


@users_bp.route('/settings', methods=['PUT'])
@jwt_required()
def update_settings():
    schema = UpdateSettingsSchema()
    errors = schema.validate(request.json or {})
    if errors:
        return jsonify({'error': 'Validation Error', 'message': errors}), 422
    user_id = int(get_jwt_identity())
    data, error = UserService.update_settings(user_id, request.json.get('preferences', {}))
    if error:
        return jsonify({'error': error}), 404
    return jsonify(data), 200


@users_bp.route('/avatar', methods=['POST'])
@jwt_required()
def upload_avatar():
    avatar_url = (request.json or {}).get('avatar_url')
    if not avatar_url:
        return jsonify({'error': 'avatar_url is required'}), 422
    user_id = int(get_jwt_identity())
    data, error = UserService.update_avatar(user_id, avatar_url)
    if error:
        return jsonify({'error': error}), 404
    return jsonify(data), 200


@users_bp.route('/avatar', methods=['DELETE'])
@jwt_required()
def delete_avatar():
    user_id = int(get_jwt_identity())
    success, error = UserService.delete_avatar(user_id)
    if error:
        return jsonify({'error': error}), 404
    return jsonify({'message': 'Avatar deleted'}), 200

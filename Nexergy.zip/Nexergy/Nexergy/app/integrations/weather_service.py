"""Servicio de integración con OpenWeatherMap"""
import os
import requests


class WeatherService:
    """Servicio para obtener datos meteorológicos"""

    def __init__(self):
        self.api_key = os.getenv('OPENWEATHERMAP_API_KEY', 'demo_key')
        self.base_url = 'https://api.openweathermap.org/data/2.5'

    def get_weather(self, lat: float, lon: float, units: str = 'metric'):
        """Obtiene clima actual para coordenadas"""
        try:
            url = f"{self.base_url}/weather"
            params = {
                'lat': lat,
                'lon': lon,
                'appid': self.api_key,
                'units': units
            }
            
            response = requests.get(url, params=params, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'success': True,
                    'temperature': data.get('main', {}).get('temp'),
                    'description': data.get('weather', [{}])[0].get('description'),
                    'humidity': data.get('main', {}).get('humidity'),
                    'pressure': data.get('main', {}).get('pressure'),
                    'wind_speed': data.get('wind', {}).get('speed'),
                    'cloudiness': data.get('clouds', {}).get('all')
                }
            else:
                return {
                    'success': False,
                    'error': f'API returned {response.status_code}'
                }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def get_forecast(self, lat: float, lon: float, days: int = 5):
        """Obtiene pronóstico del tiempo"""
        try:
            url = f"{self.base_url}/forecast"
            params = {
                'lat': lat,
                'lon': lon,
                'appid': self.api_key,
                'cnt': days * 8  # 8 predicciones por día
            }
            
            response = requests.get(url, params=params, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'success': True,
                    'forecasts': data.get('list', [])[:days * 8]
                }
            else:
                return {
                    'success': False,
                    'error': f'API returned {response.status_code}'
                }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

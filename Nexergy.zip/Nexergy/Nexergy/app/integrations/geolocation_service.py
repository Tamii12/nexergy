"""Servicio de geolocalización"""
import os
import requests


class GeolocationService:
    """Servicio para operaciones de geolocalización"""

    def __init__(self):
        self.api_key = os.getenv('GEOLOCATION_API_KEY', 'demo_key')

    def reverse_geocoding(self, lat: float, lon: float):
        """Obtiene dirección desde coordenadas (reverse geocoding)"""
        try:
            url = 'https://nominatim.openstreetmap.org/reverse'
            params = {
                'lat': lat,
                'lon': lon,
                'format': 'json'
            }
            
            # Nominatim requiere User-Agent
            headers = {'User-Agent': 'Nexergy/1.0'}
            
            response = requests.get(url, params=params, headers=headers, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                address = data.get('address', {})
                return {
                    'success': True,
                    'address': data.get('address'),
                    'city': address.get('city', ''),
                    'country': address.get('country', ''),
                    'display_name': data.get('display_name', '')
                }
            else:
                return {
                    'success': False,
                    'error': f'API returned {response.status_code}'
                }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def forward_geocoding(self, address: str):
        """Obtiene coordenadas desde dirección (forward geocoding)"""
        try:
            url = 'https://nominatim.openstreetmap.org/search'
            params = {
                'q': address,
                'format': 'json'
            }
            
            headers = {'User-Agent': 'Nexergy/1.0'}
            response = requests.get(url, params=params, headers=headers, timeout=5)
            
            if response.status_code == 200:
                results = response.json()
                if results:
                    first_result = results[0]
                    return {
                        'success': True,
                        'lat': float(first_result.get('lat', 0)),
                        'lon': float(first_result.get('lon', 0)),
                        'display_name': first_result.get('display_name', ''),
                        'importance': first_result.get('importance', 0)
                    }
                else:
                    return {
                        'success': False,
                        'error': 'No results found'
                    }
            else:
                return {
                    'success': False,
                    'error': f'API returned {response.status_code}'
                }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

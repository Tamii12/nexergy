from datetime import datetime
from app.extensions import db
from app.models.device import Device
from app.models.home import Home
from app.models.energy_reading import EnergyReading
from app.devices.events import emit_device_update


class DeviceService:

    @staticmethod
    def _verify_ownership(user_id, home_id):
        return Home.query.filter_by(id=home_id, user_id=user_id).first()

    @staticmethod
    def get_devices(user_id):
        homes = Home.query.filter_by(user_id=user_id).all()
        home_ids = [h.id for h in homes]
        if not home_ids:
            return [], None
        devices = Device.query.filter(Device.home_id.in_(home_ids)).all()
        return [d.to_dict() for d in devices], None

    @staticmethod
    def get_device(user_id, device_id):
        device = Device.query.get(device_id)
        if not device:
            return None, 'Device not found'
        home = Home.query.filter_by(id=device.home_id, user_id=user_id).first()
        if not home:
            return None, 'Device not found'
        return device.to_dict(), None

    @staticmethod
    def create_device(user_id, data):
        home = DeviceService._verify_ownership(user_id, data['home_id'])
        if not home:
            return None, 'Home not found'
        device = Device(
            home_id=data['home_id'], name=data['name'], type=data['type'],
            status='offline', metadata_json=data.get('metadata')
        )
        db.session.add(device)
        db.session.commit()
        return device.to_dict(), None

    @staticmethod
    def update_device(user_id, device_id, data):
        device = Device.query.get(device_id)
        if not device:
            return None, 'Device not found'
        if not DeviceService._verify_ownership(user_id, device.home_id):
            return None, 'Device not found'
        for key, value in data.items():
            if key == 'metadata':
                device.metadata_json = value
            elif hasattr(device, key):
                setattr(device, key, value)
        db.session.commit()
        return device.to_dict(), None

    @staticmethod
    def delete_device(user_id, device_id):
        device = Device.query.get(device_id)
        if not device:
            return False, 'Device not found'
        if not DeviceService._verify_ownership(user_id, device.home_id):
            return False, 'Device not found'
        db.session.delete(device)
        db.session.commit()
        return True, None

    @staticmethod
    def control_device(user_id, device_id, action):
        device = Device.query.get(device_id)
        if not device:
            return None, 'Device not found'
        if not DeviceService._verify_ownership(user_id, device.home_id):
            return None, 'Device not found'

        if action == 'on':
            device.status = 'online'
        elif action == 'off':
            device.status = 'offline'
        elif action == 'restart':
            device.status = 'online'
        device.updated_at = datetime.utcnow()
        db.session.commit()
        emit_device_update(device)
        return device.to_dict(), None

    @staticmethod
    def get_device_status(user_id, device_id):
        device = Device.query.get(device_id)
        if not device:
            return None, 'Device not found'
        if not DeviceService._verify_ownership(user_id, device.home_id):
            return None, 'Device not found'
        return {'id': device.id, 'status': device.status, 'last_reading': device.last_reading.isoformat() if device.last_reading else None}, None

    @staticmethod
    def get_device_history(user_id, device_id, page=1, per_page=50):
        device = Device.query.get(device_id)
        if not device:
            return None, 'Device not found'
        if not DeviceService._verify_ownership(user_id, device.home_id):
            return None, 'Device not found'
        pagination = EnergyReading.query.filter_by(device_id=device_id).order_by(
            EnergyReading.timestamp.desc()
        ).paginate(page=page, per_page=per_page, error_out=False)
        return {
            'readings': [r.to_dict() for r in pagination.items],
            'total': pagination.total, 'pages': pagination.pages
        }, None

from app.core.base_repository import BaseRepository
from app.models import Device, Home
from sqlalchemy import and_


class DevicesRepository(BaseRepository):
    """Repository para operaciones de dispositivos"""

    def get_home_devices(self, home_id: int):
        """Obtiene todos los dispositivos del hogar"""
        return Device.query.filter_by(home_id=home_id).all()

    def get_device_by_id(self, device_id: int):
        """Obtiene dispositivo por ID"""
        return Device.query.get(device_id)

    def create_device(self, home_id: int, **data):
        """Crea nuevo dispositivo"""
        device = Device(home_id=home_id, **data)
        self.db.session.add(device)
        self.db.session.commit()
        return device

    def update_device(self, device_id: int, **data):
        """Actualiza dispositivo"""
        device = Device.query.get(device_id)
        if device:
            for key, value in data.items():
                if hasattr(device, key):
                    setattr(device, key, value)
            self.db.session.commit()
        return device

    def delete_device(self, device_id: int):
        """Elimina dispositivo"""
        device = Device.query.get(device_id)
        if device:
            self.db.session.delete(device)
            self.db.session.commit()
        return device

    def get_devices_by_type(self, home_id: int, device_type: str):
        """Obtiene dispositivos por tipo"""
        return Device.query.filter(
            and_(
                Device.home_id == home_id,
                Device.type == device_type
            )
        ).all()

    def update_device_status(self, device_id: int, status: str):
        """Actualiza estado del dispositivo"""
        device = Device.query.get(device_id)
        if device:
            device.status = status
            self.db.session.commit()
        return device

    def get_offline_devices(self, home_id: int):
        """Obtiene dispositivos offline"""
        return Device.query.filter(
            and_(
                Device.home_id == home_id,
                Device.status == 'offline'
            )
        ).all()

from app.extensions import ma
from marshmallow import fields, validate

DEVICE_TYPES = [
    'smart_meter', 'light', 'ac', 'heater', 'refrigerator',
    'washer', 'dryer', 'oven', 'tv', 'computer', 'fan',
    'water_heater', 'solar_panel', 'battery', 'ev_charger', 'other'
]


class CreateDeviceSchema(ma.Schema):
    home_id = fields.Integer(required=True)
    name = fields.String(required=True, validate=validate.Length(min=2, max=100))
    type = fields.String(required=True, validate=validate.OneOf(DEVICE_TYPES))
    metadata = fields.Dict(load_default=None)


class UpdateDeviceSchema(ma.Schema):
    name = fields.String(validate=validate.Length(min=2, max=100))
    type = fields.String(validate=validate.OneOf(DEVICE_TYPES))
    metadata = fields.Dict()


class ControlDeviceSchema(ma.Schema):
    action = fields.String(required=True, validate=validate.OneOf(['on', 'off', 'restart']))

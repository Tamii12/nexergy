from app.extensions import socketio


def emit_device_update(device):
    socketio.emit('device_update', {
        'device_id': device.id,
        'status': device.status,
        'name': device.name,
        'type': device.type,
        'last_reading': device.last_reading.isoformat() if device.last_reading else None
    }, namespace='/devices')


def emit_device_alert(device, message):
    socketio.emit('device_alert', {
        'device_id': device.id,
        'name': device.name,
        'message': message
    }, namespace='/devices')

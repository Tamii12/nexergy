DEVICE_TYPES = [
    'smart_meter', 'light', 'ac', 'heater', 'refrigerator',
    'washer', 'dryer', 'oven', 'tv', 'computer', 'fan',
    'water_heater', 'solar_panel', 'battery', 'ev_charger', 'other'
]

STATUS_OPTIONS = ['online', 'offline', 'error']

from app.extensions import socketio


def emit_new_alert(alert):
    socketio.emit('new_alert', {
        'id': alert.id,
        'type': alert.type,
        'title': alert.title,
        'message': alert.message,
        'severity': alert.severity,
        'created_at': alert.created_at.isoformat() if alert.created_at else None
    }, namespace='/alerts', room=f'user_{alert.user_id}')

from app.core.base_repository import BaseRepository
from app.models import Alert, AlertRule
from sqlalchemy import and_, desc


class AlertsRepository(BaseRepository):
    """Repository para operaciones de alertas"""

    def get_user_alerts(self, user_id: int, limit: int = 50):
        """Obtiene alertas del usuario"""
        return Alert.query.filter_by(user_id=user_id).order_by(
            desc(Alert.created_at)
        ).limit(limit).all()

    def get_alert_by_id(self, alert_id: int):
        """Obtiene alerta específica"""
        return Alert.query.get(alert_id)

    def create_alert(self, user_id: int, **data):
        """Crea nueva alerta"""
        alert = Alert(user_id=user_id, **data)
        self.db.session.add(alert)
        self.db.session.commit()
        return alert

    def mark_as_read(self, alert_id: int):
        """Marca alerta como leída"""
        alert = Alert.query.get(alert_id)
        if alert:
            alert.is_read = True
            self.db.session.commit()
        return alert

    def get_unread_alerts(self, user_id: int):
        """Obtiene alertas no leídas"""
        return Alert.query.filter(
            and_(
                Alert.user_id == user_id,
                Alert.is_read == False
            )
        ).all()

    def delete_alert(self, alert_id: int):
        """Elimina alerta"""
        alert = Alert.query.get(alert_id)
        if alert:
            self.db.session.delete(alert)
            self.db.session.commit()
        return alert

    def get_user_alert_rules(self, user_id: int):
        """Obtiene reglas de alerta del usuario"""
        return AlertRule.query.filter_by(user_id=user_id).all()

    def create_alert_rule(self, user_id: int, **data):
        """Crea nueva regla de alerta"""
        rule = AlertRule(user_id=user_id, **data)
        self.db.session.add(rule)
        self.db.session.commit()
        return rule

    def update_alert_rule(self, rule_id: int, **data):
        """Actualiza regla de alerta"""
        rule = AlertRule.query.get(rule_id)
        if rule:
            for key, value in data.items():
                if hasattr(rule, key):
                    setattr(rule, key, value)
            self.db.session.commit()
        return rule

    def delete_alert_rule(self, rule_id: int):
        """Elimina regla de alerta"""
        rule = AlertRule.query.get(rule_id)
        if rule:
            self.db.session.delete(rule)
            self.db.session.commit()
        return rule

from app.extensions import ma
from marshmallow import fields, validate


class CreateRuleSchema(ma.Schema):
    name = fields.String(required=True, validate=validate.Length(min=2, max=100))
    condition = fields.Dict(required=True)


class UpdateRuleSchema(ma.Schema):
    name = fields.String(validate=validate.Length(min=2, max=100))
    condition = fields.Dict()

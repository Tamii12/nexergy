ALERT_TYPES = ['high_consumption', 'device_error', 'goal_exceeded', 'unusual_pattern', 'system']
SEVERITIES = ['info', 'warning', 'critical']

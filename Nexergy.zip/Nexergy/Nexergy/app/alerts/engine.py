from datetime import datetime
from app.extensions import db
from app.models.alert import Alert
from app.models.alert_rule import AlertRule
from app.models.energy_reading import EnergyReading
from app.models.home import Home


class AlertEngine:

    @staticmethod
    def evaluate_rules(user_id):
        rules = AlertRule.query.filter_by(user_id=user_id, is_active=True).all()
        generated = []
        for rule in rules:
            condition = rule.condition_json or {}
            ctype = condition.get('type')
            if ctype == 'threshold':
                alert = AlertEngine._check_threshold(user_id, rule, condition)
                if alert:
                    generated.append(alert)
        return generated

    @staticmethod
    def _check_threshold(user_id, rule, condition):
        max_kwh = condition.get('max_kwh', 100)
        homes = Home.query.filter_by(user_id=user_id).all()
        home_ids = [h.id for h in homes]
        if not home_ids:
            return None

        from sqlalchemy import func
        from datetime import timedelta
        now = datetime.utcnow()
        start = now - timedelta(hours=condition.get('period_hours', 24))

        total = db.session.query(func.sum(EnergyReading.kwh)).filter(
            EnergyReading.home_id.in_(home_ids),
            EnergyReading.timestamp >= start
        ).scalar()

        if total and float(total) > max_kwh:
            alert = Alert(
                user_id=user_id, rule_id=rule.id, type='high_consumption',
                title=f'Consumo alto: {float(total):.1f} kWh',
                message=f'Tu consumo de las últimas {condition.get("period_hours", 24)}h excede {max_kwh} kWh',
                severity='warning'
            )
            db.session.add(alert)
            db.session.commit()
            return alert
        return None

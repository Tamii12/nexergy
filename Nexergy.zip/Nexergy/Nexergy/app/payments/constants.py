"""Constants para el módulo de pagos"""

# Estados de pago
PAYMENT_STATUS_PENDING = 'pending'
PAYMENT_STATUS_COMPLETED = 'completed'
PAYMENT_STATUS_FAILED = 'failed'
PAYMENT_STATUS_REFUNDED = 'refunded'

PAYMENT_STATUSES = [
    PAYMENT_STATUS_PENDING,
    PAYMENT_STATUS_COMPLETED,
    PAYMENT_STATUS_FAILED,
    PAYMENT_STATUS_REFUNDED
]

# Estados de suscripción
SUBSCRIPTION_STATUS_ACTIVE = 'active'
SUBSCRIPTION_STATUS_CANCELED = 'canceled'
SUBSCRIPTION_STATUS_PAST_DUE = 'past_due'

SUBSCRIPTION_STATUSES = [
    SUBSCRIPTION_STATUS_ACTIVE,
    SUBSCRIPTION_STATUS_CANCELED,
    SUBSCRIPTION_STATUS_PAST_DUE
]

# Planes de suscripción
PLAN_BASIC = 'basic'
PLAN_PREMIUM = 'premium'
PLAN_ENTERPRISE = 'enterprise'

PLANS = [PLAN_BASIC, PLAN_PREMIUM, PLAN_ENTERPRISE]

# Precios (USD)
PLAN_PRICES = {
    PLAN_BASIC: 9.99,
    PLAN_PREMIUM: 19.99,
    PLAN_ENTERPRISE: 49.99
}

# Características por plan
PLAN_FEATURES = {
    PLAN_BASIC: {
        'max_devices': 5,
        'reports': 'monthly',
        'support': 'email'
    },
    PLAN_PREMIUM: {
        'max_devices': 20,
        'reports': 'weekly',
        'support': 'priority'
    },
    PLAN_ENTERPRISE: {
        'max_devices': 'unlimited',
        'reports': 'daily',
        'support': '24/7'
    }
}

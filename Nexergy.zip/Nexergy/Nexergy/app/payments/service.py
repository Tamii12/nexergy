"""Servicio de lógica de negocio para pagos"""
from app.core.base_service import BaseService
from app.payments.repository import PaymentsRepository
from app.payments.constants import PAYMENT_STATUS_COMPLETED, SUBSCRIPTION_STATUS_ACTIVE
from app.models import Payment
import os


class PaymentsService(BaseService):
    """Servicio para operaciones de pagos"""

    def __init__(self):
        super().__init__()
        self.repository = PaymentsRepository()

    def get_user_payments(self, user_id: int):
        """Obtiene pagos del usuario"""
        return self.repository.get_user_payments(user_id)

    def get_payment(self, payment_id: int):
        """Obtiene detalles de un pago"""
        return self.repository.get_payment_by_id(payment_id)

    def create_payment(self, user_id: int, amount: float, currency: str = 'USD', description: str = None):
        """Crea nuevo pago (inicialmente en estado pending)"""
        payment = self.repository.create_payment(
            user_id=user_id,
            amount=amount,
            currency=currency,
            status='pending'
        )
        return payment

    def update_payment_status(self, payment_id: int, status: str, stripe_payment_id: str = None):
        """Actualiza estado del pago"""
        data = {'status': status}
        if stripe_payment_id:
            data['stripe_payment_id'] = stripe_payment_id
        return self.repository.update_payment(payment_id, **data)

    def create_subscription(self, user_id: int, plan: str):
        """Crea nueva suscripción"""
        from datetime import datetime, timedelta
        current_period_end = datetime.utcnow() + timedelta(days=30)
        return self.repository.create_subscription(
            user_id=user_id,
            plan=plan,
            status=SUBSCRIPTION_STATUS_ACTIVE,
            current_period_end=current_period_end
        )

    def get_user_subscription(self, user_id: int):
        """Obtiene suscripción del usuario"""
        return self.repository.get_user_subscription(user_id)

    def cancel_subscription(self, user_id: int):
        """Cancela suscripción del usuario"""
        sub = self.repository.get_user_subscription(user_id)
        if sub:
            return self.repository.update_subscription(sub.id, status='canceled')
        return None

    def process_payment(self, user_id: int, amount: float, currency: str = 'USD'):
        """Procesa un pago (simulado)"""
        # En producción, integrar con Stripe/PayPal aquí
        payment = self.create_payment(user_id, amount, currency)
        # Simular éxito
        self.update_payment_status(payment.id, PAYMENT_STATUS_COMPLETED, 'stripe_mock_id')
        return payment

    def create_invoice(self, user_id: int, payment_id: int):
        """Crea factura para un pago"""
        from datetime import datetime
        invoice_number = f"INV-{payment_id}-{datetime.utcnow().timestamp()}"
        return self.repository.create_invoice(
            user_id=user_id,
            payment_id=payment_id,
            invoice_number=invoice_number
        )

    def get_user_invoices(self, user_id: int):
        """Obtiene facturas del usuario"""
        return self.repository.get_user_invoices(user_id)

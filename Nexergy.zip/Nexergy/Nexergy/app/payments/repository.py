"""Repository para operaciones de pagos"""
from app.core.base_repository import BaseRepository
from app.models import Payment, Invoice, Subscription
from sqlalchemy import desc


class PaymentsRepository(BaseRepository):
    """Repository para operaciones de pagos"""

    def get_user_payments(self, user_id: int, limit: int = 50):
        """Obtiene pagos del usuario"""
        return Payment.query.filter_by(user_id=user_id).order_by(
            desc(Payment.created_at)
        ).limit(limit).all()

    def get_payment_by_id(self, payment_id: int):
        """Obtiene pago específico"""
        return Payment.query.get(payment_id)

    def create_payment(self, user_id: int, **data):
        """Crea nuevo pago"""
        payment = Payment(user_id=user_id, **data)
        self.db.session.add(payment)
        self.db.session.commit()
        return payment

    def update_payment(self, payment_id: int, **data):
        """Actualiza pago"""
        payment = Payment.query.get(payment_id)
        if payment:
            for key, value in data.items():
                if hasattr(payment, key):
                    setattr(payment, key, value)
            self.db.session.commit()
        return payment

    def get_user_subscription(self, user_id: int):
        """Obtiene suscripción activa del usuario"""
        return Subscription.query.filter_by(user_id=user_id).first()

    def create_subscription(self, user_id: int, **data):
        """Crea nueva suscripción"""
        sub = Subscription(user_id=user_id, **data)
        self.db.session.add(sub)
        self.db.session.commit()
        return sub

    def update_subscription(self, subscription_id: int, **data):
        """Actualiza suscripción"""
        sub = Subscription.query.get(subscription_id)
        if sub:
            for key, value in data.items():
                if hasattr(sub, key):
                    setattr(sub, key, value)
            self.db.session.commit()
        return sub

    def create_invoice(self, user_id: int, **data):
        """Crea nueva factura"""
        invoice = Invoice(user_id=user_id, **data)
        self.db.session.add(invoice)
        self.db.session.commit()
        return invoice

    def get_user_invoices(self, user_id: int, limit: int = 50):
        """Obtiene facturas del usuario"""
        return Invoice.query.filter_by(user_id=user_id).order_by(
            desc(Invoice.created_at)
        ).limit(limit).all()

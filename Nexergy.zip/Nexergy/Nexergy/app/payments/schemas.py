"""Schemas para validación de datos de pagos"""
from marshmallow import Schema, fields, validate, validates, ValidationError


class PaymentCreateSchema(Schema):
    amount = fields.Decimal(required=True, places=2, validate=validate.Range(min=0.01))
    currency = fields.String(missing='USD', validate=validate.OneOf(['USD', 'EUR', 'ARS']))
    description = fields.String(missing='Pago en Nexergy')

    @validates('amount')
    def validate_amount(self, value):
        if value <= 0:
            raise ValidationError('Amount must be greater than 0')


class PaymentSchema(Schema):
    id = fields.Integer()
    user_id = fields.Integer()
    amount = fields.Decimal(places=2)
    currency = fields.String()
    status = fields.String()
    stripe_payment_id = fields.String()
    created_at = fields.DateTime()
    updated_at = fields.DateTime()


class SubscriptionSchema(Schema):
    id = fields.Integer()
    user_id = fields.Integer()
    plan = fields.String(validate=validate.OneOf(['basic', 'premium', 'enterprise']))
    status = fields.String()
    stripe_subscription_id = fields.String()
    current_period_end = fields.DateTime()
    created_at = fields.DateTime()


class InvoiceSchema(Schema):
    id = fields.Integer()
    user_id = fields.Integer()
    payment_id = fields.Integer()
    invoice_number = fields.String()
    pdf_url = fields.String()
    created_at = fields.DateTime()

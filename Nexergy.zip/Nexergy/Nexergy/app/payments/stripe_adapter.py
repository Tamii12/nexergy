"""Adaptador para integración con Stripe"""
import os
import stripe


class StripeAdapter:
    """Adaptador para operaciones con Stripe"""

    def __init__(self):
        stripe.api_key = os.getenv('STRIPE_SECRET_KEY', 'sk_test_mock')

    def create_payment_intent(self, amount: int, currency: str = 'usd', description: str = None):
        """Crea payment intent en Stripe"""
        try:
            intent = stripe.PaymentIntent.create(
                amount=amount,  # en centavos
                currency=currency,
                description=description or 'Nexergy Energy Payment'
            )
            return {
                'success': True,
                'client_secret': intent.client_secret,
                'payment_intent_id': intent.id
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def retrieve_payment_intent(self, payment_intent_id: str):
        """Obtiene detalles de payment intent"""
        try:
            intent = stripe.PaymentIntent.retrieve(payment_intent_id)
            return {
                'success': True,
                'status': intent.status,
                'amount': intent.amount,
                'currency': intent.currency
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def create_subscription(self, customer_id: str, price_id: str):
        """Crea suscripción en Stripe"""
        try:
            subscription = stripe.Subscription.create(
                customer=customer_id,
                items=[{'price': price_id}]
            )
            return {
                'success': True,
                'subscription_id': subscription.id,
                'status': subscription.status
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def cancel_subscription(self, subscription_id: str):
        """Cancela suscripción en Stripe"""
        try:
            subscription = stripe.Subscription.delete(subscription_id)
            return {
                'success': True,
                'status': subscription.status
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

    def create_webhook_endpoint(self, url: str, events: list):
        """Crea endpoint webhook en Stripe"""
        try:
            webhook = stripe.WebhookEndpoint.create(
                url=url,
                enabled_events=events
            )
            return {
                'success': True,
                'webhook_id': webhook.id,
                'secret': webhook.secret
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }

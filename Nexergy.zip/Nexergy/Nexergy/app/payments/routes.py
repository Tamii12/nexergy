"""Endpoints para operaciones de pagos"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from marshmallow import ValidationError
from app.core.decorators import handle_exceptions
from app.payments.service import PaymentsService
from app.payments.schemas import PaymentCreateSchema, SubscriptionSchema, InvoiceSchema
from app.models import Payment
from app.extensions import db

payments_bp = Blueprint('payments', __name__)
service = PaymentsService()


@payments_bp.route('/payments', methods=['GET'])
@jwt_required()
@handle_exceptions
def get_payments():
    """Obtiene historial de pagos del usuario"""
    user_id = get_jwt_identity()
    payments = service.get_user_payments(user_id)
    
    schema = PaymentCreateSchema(many=True)
    return jsonify({
        'success': True,
        'payments': schema.dump(payments)
    }), 200


@payments_bp.route('/payments/<int:payment_id>', methods=['GET'])
@jwt_required()
@handle_exceptions
def get_payment(payment_id):
    """Obtiene detalles de un pago específico"""
    user_id = get_jwt_identity()
    payment = service.get_payment(payment_id)
    
    if not payment or payment.user_id != user_id:
        return jsonify({'error': 'Payment not found'}), 404
    
    schema = PaymentCreateSchema()
    return jsonify({
        'success': True,
        'payment': schema.dump(payment)
    }), 200


@payments_bp.route('/checkout', methods=['POST'])
@jwt_required()
@handle_exceptions
def checkout():
    """Inicia proceso de pago"""
    user_id = get_jwt_identity()
    data = request.json
    
    schema = PaymentCreateSchema()
    try:
        validated_data = schema.load(data)
    except ValidationError as err:
        return jsonify({'success': False, 'errors': err.messages}), 400
    
    payment = service.process_payment(user_id, float(validated_data['amount']), validated_data['currency'])
    
    return jsonify({
        'success': True,
        'payment_id': payment.id,
        'amount': float(payment.amount),
        'status': payment.status
    }), 201


@payments_bp.route('/subscription', methods=['GET'])
@jwt_required()
@handle_exceptions
def get_subscription():
    """Obtiene suscripción activa del usuario"""
    user_id = get_jwt_identity()
    subscription = service.get_user_subscription(user_id)
    
    if not subscription:
        return jsonify({'success': False, 'message': 'No active subscription'}), 404
    
    schema = SubscriptionSchema()
    return jsonify({
        'success': True,
        'subscription': schema.dump(subscription)
    }), 200


@payments_bp.route('/subscription', methods=['POST'])
@jwt_required()
@handle_exceptions
def create_subscription():
    """Crea nueva suscripción"""
    user_id = get_jwt_identity()
    data = request.json
    plan = data.get('plan')
    
    if not plan or plan not in ['basic', 'premium', 'enterprise']:
        return jsonify({'success': False, 'error': 'Invalid plan'}), 400
    
    subscription = service.create_subscription(user_id, plan)
    
    schema = SubscriptionSchema()
    return jsonify({
        'success': True,
        'subscription': schema.dump(subscription)
    }), 201


@payments_bp.route('/subscription', methods=['DELETE'])
@jwt_required()
@handle_exceptions
def cancel_subscription():
    """Cancela suscripción del usuario"""
    user_id = get_jwt_identity()
    subscription = service.cancel_subscription(user_id)
    
    if not subscription:
        return jsonify({'success': False, 'error': 'No subscription to cancel'}), 404
    
    return jsonify({
        'success': True,
        'message': 'Subscription canceled'
    }), 200


@payments_bp.route('/invoices', methods=['GET'])
@jwt_required()
@handle_exceptions
def get_invoices():
    """Obtiene facturas del usuario"""
    user_id = get_jwt_identity()
    invoices = service.get_user_invoices(user_id)
    
    schema = InvoiceSchema(many=True)
    return jsonify({
        'success': True,
        'invoices': schema.dump(invoices)
    }), 200

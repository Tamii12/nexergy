def register_blueprints(app):
    from app.auth.routes import auth_bp
    from app.users.routes import users_bp
    from app.dashboard.routes import dashboard_bp
    from app.energy.routes import energy_bp
    from app.devices.routes import devices_bp
    from app.alerts.routes import alerts_bp
    from app.recommendations.routes import recommendations_bp
    from app.payments.routes import payments_bp
    from app.ai.routes import ai_bp
    from app.notifications.routes import notifications_bp
    from app.reports.routes import reports_bp
    from app.gamification.routes import gamification_bp
    from app.admin.routes import admin_bp

    app.register_blueprint(auth_bp, url_prefix='/api/v1/auth')
    app.register_blueprint(users_bp, url_prefix='/api/v1/users')
    app.register_blueprint(dashboard_bp, url_prefix='/api/v1/dashboard')
    app.register_blueprint(energy_bp, url_prefix='/api/v1/energy')
    app.register_blueprint(devices_bp, url_prefix='/api/v1/devices')
    app.register_blueprint(alerts_bp, url_prefix='/api/v1/alerts')
    app.register_blueprint(recommendations_bp, url_prefix='/api/v1/recommendations')
    app.register_blueprint(payments_bp, url_prefix='/api/v1/payments')
    app.register_blueprint(ai_bp, url_prefix='/api/v1/ai')
    app.register_blueprint(notifications_bp, url_prefix='/api/v1/notifications')
    app.register_blueprint(reports_bp, url_prefix='/api/v1/reports')
    app.register_blueprint(gamification_bp, url_prefix='/api/v1/gamification')
    app.register_blueprint(admin_bp, url_prefix='/api/v1/admin')

ENERGY_PERIODS = ['hourly', 'daily', 'weekly', 'monthly', 'yearly']

BASE_CONSUMPTION = {
    'smart_meter': 0.0,
    'light': 0.06,
    'ac': 1.5,
    'heater': 2.0,
    'refrigerator': 0.15,
    'washer': 0.5,
    'dryer': 2.5,
    'oven': 2.3,
    'tv': 0.1,
    'computer': 0.3,
    'fan': 0.075,
    'water_heater': 4.0,
    'solar_panel': -0.5,
    'battery': 0.0,
    'ev_charger': 7.2,
    'other': 0.2
}

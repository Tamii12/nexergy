import random
import math
from datetime import datetime
from app.extensions import db
from app.models.device import Device
from app.models.energy_reading import EnergyReading
from app.models.home import Home
from app.energy.constants import BASE_CONSUMPTION


class EnergySimulator:

    @staticmethod
    def generate_reading(device):
        now = datetime.utcnow()
        hour = now.hour
        base = BASE_CONSUMPTION.get(device.type, 0.2)

        # Time-of-day factor
        if 6 <= hour <= 9 or 18 <= hour <= 22:
            time_factor = 1.3
        elif 23 <= hour or hour <= 5:
            time_factor = 0.6
        else:
            time_factor = 1.0

        variation = random.uniform(0.8, 1.2)
        spike = random.random()
        spike_factor = 1.5 if spike > 0.95 else 1.0

        kwh = abs(base * time_factor * variation * spike_factor) / 60.0
        voltage = 120 + random.uniform(-5, 5)
        current = kwh * 1000 / max(voltage, 1)
        power_factor = round(random.uniform(0.85, 0.99), 3)

        return EnergyReading(
            home_id=device.home_id,
            device_id=device.id,
            timestamp=now,
            kwh=round(kwh, 4),
            voltage=round(voltage, 2),
            current=round(current, 2),
            power_factor=power_factor
        )

    @staticmethod
    def simulate_all():
        devices = Device.query.filter_by(status='online').all()
        readings = []
        for device in devices:
            reading = EnergySimulator.generate_reading(device)
            readings.append(reading)
            device.last_reading = datetime.utcnow()
        if readings:
            db.session.add_all(readings)
            db.session.commit()
        return len(readings)

from datetime import datetime, timedelta
from sqlalchemy import func
from app.extensions import db
from app.models.home import Home
from app.models.energy_reading import EnergyReading
from app.models.saving_goal import SavingGoal


class EnergyService:

    @staticmethod
    def _get_home_ids(user_id):
        homes = Home.query.filter_by(user_id=user_id).all()
        return [h.id for h in homes]

    @staticmethod
    def get_readings(user_id, page=1, per_page=50, device_id=None, start=None, end=None):
        home_ids = EnergyService._get_home_ids(user_id)
        if not home_ids:
            return {'readings': [], 'total': 0}, None

        query = EnergyReading.query.filter(EnergyReading.home_id.in_(home_ids))
        if device_id:
            query = query.filter_by(device_id=device_id)
        if start:
            query = query.filter(EnergyReading.timestamp >= start)
        if end:
            query = query.filter(EnergyReading.timestamp <= end)

        pagination = query.order_by(EnergyReading.timestamp.desc()).paginate(page=page, per_page=per_page, error_out=False)

        return {
            'readings': [r.to_dict() for r in pagination.items],
            'total': pagination.total,
            'pages': pagination.pages,
            'current_page': pagination.page
        }, None

    @staticmethod
    def get_consumption(user_id, period='daily'):
        home_ids = EnergyService._get_home_ids(user_id)
        if not home_ids:
            return {'data': [], 'total_kwh': 0}, None

        now = datetime.utcnow()
        if period == 'daily':
            start = datetime.combine(now.date(), datetime.min.time())
            group_format = '%H:00'
        elif period == 'monthly':
            start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            group_format = '%Y-%m-%d'
        elif period == 'yearly':
            start = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
            group_format = '%Y-%m'
        else:
            start = now - timedelta(days=7)
            group_format = '%Y-%m-%d'

        readings = EnergyReading.query.filter(
            EnergyReading.home_id.in_(home_ids),
            EnergyReading.timestamp >= start
        ).order_by(EnergyReading.timestamp).all()

        grouped = {}
        for r in readings:
            key = r.timestamp.strftime(group_format)
            grouped[key] = grouped.get(key, 0) + float(r.kwh)

        data = [{'period': k, 'kwh': round(v, 4)} for k, v in grouped.items()]
        total = sum(v for v in grouped.values())

        return {'data': data, 'total_kwh': round(total, 2), 'period': period}, None

    @staticmethod
    def get_comparisons(user_id):
        home_ids = EnergyService._get_home_ids(user_id)
        if not home_ids:
            return {'current_month': 0, 'previous_month': 0, 'change_percent': 0}, None

        now = datetime.utcnow()
        current_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        prev_start = (current_start - timedelta(days=1)).replace(day=1)

        current = db.session.query(func.sum(EnergyReading.kwh)).filter(
            EnergyReading.home_id.in_(home_ids), EnergyReading.timestamp >= current_start
        ).scalar() or 0

        previous = db.session.query(func.sum(EnergyReading.kwh)).filter(
            EnergyReading.home_id.in_(home_ids),
            EnergyReading.timestamp >= prev_start,
            EnergyReading.timestamp < current_start
        ).scalar() or 0

        current = float(current)
        previous = float(previous)
        change = ((current - previous) / previous * 100) if previous > 0 else 0

        return {
            'current_month': round(current, 2),
            'previous_month': round(previous, 2),
            'change_percent': round(change, 1)
        }, None

    @staticmethod
    def get_goals(user_id):
        goals = SavingGoal.query.filter_by(user_id=user_id).order_by(SavingGoal.created_at.desc()).all()
        return [g.to_dict() for g in goals], None

    @staticmethod
    def create_goal(user_id, data):
        goal = SavingGoal(user_id=user_id, target_kwh=data['target_kwh'], target_date=data['target_date'])
        db.session.add(goal)
        db.session.commit()
        return goal.to_dict(), None

    @staticmethod
    def update_goal(user_id, goal_id, data):
        goal = SavingGoal.query.filter_by(id=goal_id, user_id=user_id).first()
        if not goal:
            return None, 'Goal not found'
        for key, value in data.items():
            if hasattr(goal, key):
                setattr(goal, key, value)
        db.session.commit()
        return goal.to_dict(), None

    @staticmethod
    def delete_goal(user_id, goal_id):
        goal = SavingGoal.query.filter_by(id=goal_id, user_id=user_id).first()
        if not goal:
            return False, 'Goal not found'
        db.session.delete(goal)
        db.session.commit()
        return True, None

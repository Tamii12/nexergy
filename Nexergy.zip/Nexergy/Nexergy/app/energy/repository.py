from app.core.base_repository import BaseRepository
from app.models import Home, Device, EnergyReading
from sqlalchemy import and_, desc
from datetime import datetime, timedelta


class EnergyRepository(BaseRepository):
    """Repository para operaciones de energía"""

    def get_energy_readings(self, home_id: int, days: int = 30, device_id: int = None):
        """Obtiene lecturas energéticas del hogar"""
        date_from = datetime.utcnow() - timedelta(days=days)
        query = EnergyReading.query.filter(
            and_(
                EnergyReading.home_id == home_id,
                EnergyReading.timestamp >= date_from
            )
        )
        if device_id:
            query = query.filter(EnergyReading.device_id == device_id)
        return query.order_by(desc(EnergyReading.timestamp)).all()

    def get_reading_by_id(self, reading_id: int):
        """Obtiene lectura específica"""
        return EnergyReading.query.get(reading_id)

    def create_energy_reading(self, home_id: int, device_id: int = None, **data):
        """Crea nueva lectura energética"""
        reading = EnergyReading(home_id=home_id, device_id=device_id, **data)
        self.db.session.add(reading)
        self.db.session.commit()
        return reading

    def get_daily_consumption(self, home_id: int, date: datetime = None):
        """Obtiene consumo diario"""
        if date is None:
            date = datetime.utcnow().date()
        readings = EnergyReading.query.filter(
            and_(
                EnergyReading.home_id == home_id,
                EnergyReading.timestamp >= datetime.combine(date, datetime.min.time()),
                EnergyReading.timestamp < datetime.combine(date, datetime.max.time())
            )
        ).all()
        return sum(r.kwh for r in readings) if readings else 0

    def get_monthly_consumption(self, home_id: int, year: int, month: int):
        """Obtiene consumo mensual"""
        from datetime import date
        from calendar import monthrange
        first_day = date(year, month, 1)
        last_day = date(year, month, monthrange(year, month)[1])
        readings = EnergyReading.query.filter(
            and_(
                EnergyReading.home_id == home_id,
                EnergyReading.timestamp >= first_day,
                EnergyReading.timestamp <= last_day
            )
        ).all()
        return sum(r.kwh for r in readings) if readings else 0

    def get_yearly_consumption(self, home_id: int, year: int):
        """Obtiene consumo anual"""
        readings = EnergyReading.query.filter(
            and_(
                EnergyReading.home_id == home_id,
                EnergyReading.timestamp >= datetime(year, 1, 1),
                EnergyReading.timestamp <= datetime(year, 12, 31)
            )
        ).all()
        return sum(r.kwh for r in readings) if readings else 0

from app.extensions import ma
from marshmallow import fields, validate


class CreateGoalSchema(ma.Schema):
    target_kwh = fields.Float(required=True, validate=validate.Range(min=0.01))
    target_date = fields.Date(required=True)


class UpdateGoalSchema(ma.Schema):
    target_kwh = fields.Float(validate=validate.Range(min=0.01))
    target_date = fields.Date()
    status = fields.String(validate=validate.OneOf(['active', 'achieved', 'failed']))

"""Repository para admin"""
from app.core.base_repository import BaseRepository
from app.models import User, ActivityLog, EnergyReading, Device, Alert
from sqlalchemy import func, desc


class AdminRepository(BaseRepository):
    """Repository para operaciones admin"""

    def get_system_stats(self):
        """Obtiene estadísticas del sistema"""
        total_users = User.query.count()
        active_users = User.query.filter_by(is_active=True).count()
        verified_users = User.query.filter_by(is_verified=True).count()
        total_readings = EnergyReading.query.count()
        total_devices = Device.query.count()
        total_alerts = Alert.query.count()
        
        return {
            'total_users': total_users,
            'active_users': active_users,
            'verified_users': verified_users,
            'total_readings': total_readings,
            'total_devices': total_devices,
            'total_alerts': total_alerts,
            'system_uptime': 'N/A'
        }

    def get_all_users(self, limit: int = 100, offset: int = 0):
        """Obtiene lista de todos los usuarios"""
        return User.query.order_by(desc(User.created_at)).limit(limit).offset(offset).all()

    def get_user_detail(self, user_id: int):
        """Obtiene detalles completos de un usuario"""
        return User.query.get(user_id)

    def update_user_status(self, user_id: int, is_active: bool):
        """Actualiza estado activo/inactivo de usuario"""
        user = User.query.get(user_id)
        if user:
            user.is_active = is_active
            self.db.session.commit()
        return user

    def get_activity_logs(self, user_id: int = None, limit: int = 500):
        """Obtiene logs de actividad"""
        query = ActivityLog.query
        if user_id:
            query = query.filter_by(user_id=user_id)
        return query.order_by(desc(ActivityLog.timestamp)).limit(limit).all()

    def get_system_logs(self, action: str = None, limit: int = 500):
        """Obtiene logs del sistema"""
        query = ActivityLog.query
        if action:
            query = query.filter_by(action=action)
        return query.order_by(desc(ActivityLog.timestamp)).limit(limit).all()

    def create_activity_log(self, user_id: int, action: str, resource: str = None, ip: str = None):
        """Crea log de actividad"""
        log = ActivityLog(
            user_id=user_id,
            action=action,
            resource=resource,
            ip=ip
        )
        self.db.session.add(log)
        self.db.session.commit()
        return log

"""Servicio para admin"""
from app.core.base_service import BaseService
from app.admin.repository import AdminRepository


class AdminService(BaseService):
    """Servicio para operaciones admin"""

    def __init__(self):
        super().__init__()
        self.repository = AdminRepository()

    def get_system_stats(self):
        """Obtiene estadísticas del sistema"""
        return self.repository.get_system_stats()

    def get_all_users(self, limit: int = 100, offset: int = 0):
        """Obtiene lista de usuarios"""
        return self.repository.get_all_users(limit, offset)

    def get_user(self, user_id: int):
        """Obtiene detalles de usuario"""
        return self.repository.get_user_detail(user_id)

    def deactivate_user(self, user_id: int):
        """Desactiva una cuenta de usuario"""
        return self.repository.update_user_status(user_id, False)

    def activate_user(self, user_id: int):
        """Activa una cuenta de usuario"""
        return self.repository.update_user_status(user_id, True)

    def get_activity_logs(self, user_id: int = None):
        """Obtiene logs de actividad"""
        return self.repository.get_activity_logs(user_id)

    def get_system_logs(self, action: str = None):
        """Obtiene logs del sistema"""
        return self.repository.get_system_logs(action)

    def log_admin_action(self, admin_id: int, action: str, resource: str = None, ip: str = None):
        """Registra acción administrativo"""
        return self.repository.create_activity_log(admin_id, f'ADMIN: {action}', resource, ip)

"""Schemas para admin"""
from marshmallow import Schema, fields


class AdminStatsSchema(Schema):
    total_users = fields.Integer()
    active_users = fields.Integer()
    total_energy_readings = fields.Integer()
    total_alerts = fields.Integer()
    total_devices = fields.Integer()
    system_uptime = fields.String()


class UserManagementSchema(Schema):
    id = fields.Integer()
    email = fields.Email()
    is_active = fields.Boolean()
    is_verified = fields.Boolean()
    created_at = fields.DateTime()
    role = fields.String()


class ActivityLogSchema(Schema):
    id = fields.Integer()
    user_id = fields.Integer()
    action = fields.String()
    resource = fields.String()
    timestamp = fields.DateTime()
    ip = fields.String()

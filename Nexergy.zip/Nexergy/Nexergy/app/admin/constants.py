"""Constants para admin"""

# Acciones admin
ADMIN_ACTIONS = {
    'user_management': 'Gestión de usuarios',
    'analytics': 'Análisis del sistema',
    'system_settings': 'Configuración del sistema',
    'backup': 'Respaldo de datos',
    'logs': 'Visualizar logs'
}

# Roles disponibles
ROLE_ADMIN = 'admin'
ROLE_USER = 'user'
ROLE_MODERATOR = 'moderator'
ROLE_SUPPORT = 'support'

ROLES = [ROLE_ADMIN, ROLE_USER, ROLE_MODERATOR, ROLE_SUPPORT]

# Permisos por rol
ROLE_PERMISSIONS = {
    ROLE_ADMIN: ['*'],  # Todos los permisos
    ROLE_MODERATOR: ['user_management', 'logs', 'analytics'],
    ROLE_SUPPORT: ['logs', 'user_view'],
    ROLE_USER: []
}

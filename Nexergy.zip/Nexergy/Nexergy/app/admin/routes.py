"""Endpoints para admin"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.core.decorators import handle_exceptions
from app.admin.service import AdminService
from app.admin.schemas import AdminStatsSchema, UserManagementSchema, ActivityLogSchema

admin_bp = Blueprint('admin', __name__)
service = AdminService()


def require_admin(fn):
    """Decorador para verificar permisos admin"""
    def wrapper(*args, **kwargs):
        # En producción, verificar rol del usuario
        return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper


@admin_bp.route('/stats', methods=['GET'])
@jwt_required()
@require_admin
@handle_exceptions
def get_stats():
    """Obtiene estadísticas del sistema"""
    stats = service.get_system_stats()
    
    schema = AdminStatsSchema()
    return jsonify({
        'success': True,
        'stats': schema.dump(stats)
    }), 200


@admin_bp.route('/users', methods=['GET'])
@jwt_required()
@require_admin
@handle_exceptions
def get_users():
    """Lista todos los usuarios"""
    limit = request.args.get('limit', 50, type=int)
    offset = request.args.get('offset', 0, type=int)
    
    users = service.get_all_users(limit, offset)
    
    schema = UserManagementSchema(many=True)
    return jsonify({
        'success': True,
        'users': schema.dump(users),
        'total': len(users)
    }), 200


@admin_bp.route('/users/<int:user_id>', methods=['GET'])
@jwt_required()
@require_admin
@handle_exceptions
def get_user(user_id):
    """Obtiene detalles de usuario"""
    user = service.get_user(user_id)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    schema = UserManagementSchema()
    return jsonify({
        'success': True,
        'user': schema.dump(user)
    }), 200


@admin_bp.route('/users/<int:user_id>/deactivate', methods=['PUT'])
@jwt_required()
@require_admin
@handle_exceptions
def deactivate_user(user_id):
    """Desactiva una cuenta de usuario"""
    admin_id = get_jwt_identity()
    user = service.deactivate_user(user_id)
    service.log_admin_action(admin_id, 'DEACTIVATE_USER', f'user:{user_id}')
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify({
        'success': True,
        'message': 'User deactivated'
    }), 200


@admin_bp.route('/users/<int:user_id>/activate', methods=['PUT'])
@jwt_required()
@require_admin
@handle_exceptions
def activate_user(user_id):
    """Activa una cuenta de usuario"""
    admin_id = get_jwt_identity()
    user = service.activate_user(user_id)
    service.log_admin_action(admin_id, 'ACTIVATE_USER', f'user:{user_id}')
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify({
        'success': True,
        'message': 'User activated'
    }), 200


@admin_bp.route('/activity-logs', methods=['GET'])
@jwt_required()
@require_admin
@handle_exceptions
def get_logs():
    """Obtiene logs de actividad"""
    action = request.args.get('action')
    logs = service.get_system_logs(action)
    
    schema = ActivityLogSchema(many=True)
    return jsonify({
        'success': True,
        'logs': schema.dump(logs),
        'total': len(logs)
    }), 200

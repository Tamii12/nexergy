from datetime import datetime, timedelta
from sqlalchemy import func
from app.extensions import db
from app.models.home import Home
from app.models.energy_reading import EnergyReading
from app.models.device import Device
from app.models.recommendation import Recommendation


class RecommendationEngine:

    TIPS = [
        {'type': 'usage', 'title': 'Desconecta dispositivos en standby', 'description': 'Los dispositivos en standby consumen hasta un 10% de tu energía. Desconéctalos cuando no los uses.', 'impact_kwh': 5.0},
        {'type': 'schedule', 'title': 'Usa electrodomésticos en horas valle', 'description': 'Programa tu lavadora y secadora para funcionar en horas de menor demanda (noche).', 'impact_kwh': 8.0},
        {'type': 'temperature', 'title': 'Ajusta el termostato', 'description': 'Cada grado menos en calefacción ahorra un 7% en consumo. Mantén 20°C en invierno.', 'impact_kwh': 15.0},
        {'type': 'lighting', 'title': 'Cambia a iluminación LED', 'description': 'Las bombillas LED consumen hasta un 80% menos que las incandescentes.', 'impact_kwh': 3.0},
        {'type': 'ac', 'title': 'Limpia filtros del aire acondicionado', 'description': 'Filtros sucios aumentan el consumo un 15%. Límpialos cada mes.', 'impact_kwh': 10.0},
        {'type': 'appliance', 'title': 'Usa la lavadora a carga completa', 'description': 'Evita ciclos con poca ropa. Una carga completa es más eficiente.', 'impact_kwh': 4.0},
        {'type': 'habit', 'title': 'Apaga luces al salir', 'description': 'Un hábito simple que reduce hasta un 5% tu consumo mensual.', 'impact_kwh': 2.5},
        {'type': 'solar', 'title': 'Considera energía solar', 'description': 'Los paneles solares pueden cubrir hasta un 70% de tu consumo diurno.', 'impact_kwh': 50.0},
    ]

    @staticmethod
    def generate_for_user(user_id):
        existing = Recommendation.query.filter_by(user_id=user_id, is_applied=False).count()
        if existing >= 5:
            return []

        generated = []
        for tip in RecommendationEngine.TIPS:
            exists = Recommendation.query.filter_by(user_id=user_id, title=tip['title']).first()
            if not exists:
                rec = Recommendation(
                    user_id=user_id, type=tip['type'], title=tip['title'],
                    description=tip['description'], impact_kwh=tip['impact_kwh']
                )
                db.session.add(rec)
                generated.append(rec)
                if len(generated) >= 3:
                    break

        if generated:
            db.session.commit()
        return generated

from app.core.base_repository import BaseRepository
from app.models import Recommendation
from sqlalchemy import and_, desc


class RecommendationsRepository(BaseRepository):
    """Repository para operaciones de recomendaciones"""

    def get_user_recommendations(self, user_id: int, limit: int = 50):
        """Obtiene recomendaciones del usuario"""
        return Recommendation.query.filter_by(user_id=user_id).order_by(
            desc(Recommendation.created_at)
        ).limit(limit).all()

    def get_recommendation_by_id(self, recommendation_id: int):
        """Obtiene recomendación específica"""
        return Recommendation.query.get(recommendation_id)

    def create_recommendation(self, user_id: int, **data):
        """Crea nueva recomendación"""
        rec = Recommendation(user_id=user_id, **data)
        self.db.session.add(rec)
        self.db.session.commit()
        return rec

    def mark_as_applied(self, recommendation_id: int):
        """Marca recomendación como aplicada"""
        rec = Recommendation.query.get(recommendation_id)
        if rec:
            rec.is_applied = True
            self.db.session.commit()
        return rec

    def get_unapplied_recommendations(self, user_id: int):
        """Obtiene recomendaciones no aplicadas"""
        return Recommendation.query.filter(
            and_(
                Recommendation.user_id == user_id,
                Recommendation.is_applied == False
            )
        ).all()

    def delete_recommendation(self, recommendation_id: int):
        """Elimina recomendación"""
        rec = Recommendation.query.get(recommendation_id)
        if rec:
            self.db.session.delete(rec)
            self.db.session.commit()
        return rec

    def get_recommendations_by_type(self, user_id: int, rec_type: str):
        """Obtiene recomendaciones por tipo"""
        return Recommendation.query.filter(
            and_(
                Recommendation.user_id == user_id,
                Recommendation.type == rec_type
            )
        ).all()

from app.extensions import ma
from marshmallow import fields, validate


class RegisterSchema(ma.Schema):
    email = fields.Email(required=True)
    first_name = fields.String(required=True, validate=validate.Length(min=2, max=100))
    last_name = fields.String(required=True, validate=validate.Length(min=2, max=100))


class LoginSchema(ma.Schema):
    email = fields.Email(required=True)
    password = fields.String(required=True)


class ChangePasswordSchema(ma.Schema):
    current_password = fields.String(required=True)
    new_password = fields.String(required=True, validate=validate.Length(min=8))


class ForgotPasswordSchema(ma.Schema):
    email = fields.Email(required=True)


class ResetPasswordSchema(ma.Schema):
    token = fields.String(required=True)
    new_password = fields.String(required=True, validate=validate.Length(min=8))


class VerifyEmailSchema(ma.Schema):
    token = fields.String(required=True)

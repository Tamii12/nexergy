import secrets
import string
from datetime import datetime, timedelta
from flask import current_app
from flask_jwt_extended import create_access_token, create_refresh_token, get_jti
from app.extensions import db
from app.core.bcrypt_helpers import hash_password, check_password
from app.core.security import validate_password_strength
from app.models.user import User
from app.models.role import Role
from app.models.user_profile import UserProfile
from app.models.email_verification import EmailVerification
from app.models.password_reset import PasswordReset
from app.models.token_blacklist import TokenBlacklist
from app.models.activity_log import ActivityLog


class AuthService:

    @staticmethod
    def generate_provisional_password(length=12):
        chars = string.ascii_letters + string.digits + '!@#$%&*'
        return ''.join(secrets.choice(chars) for _ in range(length))

    @staticmethod
    def register(email, first_name, last_name):
        if User.query.filter_by(email=email.lower()).first():
            return None, 'Email already registered'

        provisional_password = AuthService.generate_provisional_password()
        user = User(
            email=email.lower(),
            password_hash=hash_password(provisional_password),
            is_verified=False,
            is_active=True,
            force_password_change=True
        )

        user_role = Role.query.filter_by(name='user').first()
        if not user_role:
            user_role = Role(name='user', description='Standard user')
            db.session.add(user_role)

        user.roles.append(user_role)
        db.session.add(user)
        db.session.flush()

        profile = UserProfile(
            user_id=user.id,
            first_name=first_name,
            last_name=last_name
        )
        db.session.add(profile)

        verification_token = secrets.token_urlsafe(32)
        verification = EmailVerification(
            user_id=user.id,
            token=verification_token,
            expires_at=datetime.utcnow() + timedelta(hours=24)
        )
        db.session.add(verification)
        db.session.commit()

        return {
            'user': user,
            'provisional_password': provisional_password,
            'verification_token': verification_token
        }, None

    @staticmethod
    def verify_email(token):
        verification = EmailVerification.query.filter_by(token=token, verified_at=None).first()
        if not verification:
            return False, 'Invalid verification token'
        if verification.is_expired():
            return False, 'Verification token expired'

        verification.verified_at = datetime.utcnow()
        user = User.query.get(verification.user_id)
        user.is_verified = True
        db.session.commit()
        return True, 'Email verified successfully'

    @staticmethod
    def login(email, password, ip=None, user_agent=None):
        user = User.query.filter_by(email=email.lower()).first()
        if not user or not check_password(user.password_hash, password):
            return None, 'Invalid email or password'
        if not user.is_active:
            return None, 'Account is deactivated'
        if not user.is_verified:
            return None, 'Email not verified. Please check your inbox.'

        additional_claims = {
            'roles': user.get_role_names(),
            'email': user.email
        }
        access_token = create_access_token(identity=str(user.id), additional_claims=additional_claims)
        refresh_token = create_refresh_token(identity=str(user.id), additional_claims=additional_claims)

        log = ActivityLog(user_id=user.id, action='login', resource='auth', ip=ip, user_agent=user_agent)
        db.session.add(log)
        db.session.commit()

        return {
            'access_token': access_token,
            'refresh_token': refresh_token,
            'user': user.to_dict(),
            'force_password_change': user.force_password_change
        }, None

    @staticmethod
    def logout(jti, token_type='access', expires_at=None):
        if expires_at is None:
            expires_at = datetime.utcnow() + timedelta(hours=1)
        blacklisted = TokenBlacklist(jti=jti, token_type=token_type, expires_at=expires_at)
        db.session.add(blacklisted)
        db.session.commit()
        return True

    @staticmethod
    def change_password(user_id, current_password, new_password):
        user = User.query.get(user_id)
        if not user:
            return False, 'User not found'
        if not check_password(user.password_hash, current_password):
            return False, 'Current password is incorrect'

        errors = validate_password_strength(new_password)
        if errors:
            return False, errors

        user.password_hash = hash_password(new_password)
        user.force_password_change = False
        db.session.commit()
        return True, 'Password changed successfully'

    @staticmethod
    def forgot_password(email):
        user = User.query.filter_by(email=email.lower()).first()
        if not user:
            return True, 'If the email exists, a reset link has been sent'

        token = secrets.token_urlsafe(32)
        reset = PasswordReset(
            user_id=user.id,
            token=token,
            expires_at=datetime.utcnow() + timedelta(hours=1)
        )
        db.session.add(reset)
        db.session.commit()
        return True, 'If the email exists, a reset link has been sent'

    @staticmethod
    def reset_password(token, new_password):
        reset = PasswordReset.query.filter_by(token=token, used_at=None).first()
        if not reset:
            return False, 'Invalid reset token'
        if reset.is_expired():
            return False, 'Reset token expired'

        errors = validate_password_strength(new_password)
        if errors:
            return False, errors

        user = User.query.get(reset.user_id)
        user.password_hash = hash_password(new_password)
        user.force_password_change = False
        reset.used_at = datetime.utcnow()
        db.session.commit()
        return True, 'Password reset successfully'

    @staticmethod
    def refresh_tokens(user_id):
        user = User.query.get(int(user_id))
        if not user or not user.is_active:
            return None, 'User not found or inactive'

        additional_claims = {
            'roles': user.get_role_names(),
            'email': user.email
        }
        access_token = create_access_token(identity=str(user.id), additional_claims=additional_claims)
        return {'access_token': access_token}, None

    @staticmethod
    def resend_verification(email):
        user = User.query.filter_by(email=email.lower()).first()
        if not user or user.is_verified:
            return True, 'If the email exists and is not verified, a new link has been sent'

        token = secrets.token_urlsafe(32)
        verification = EmailVerification(
            user_id=user.id,
            token=token,
            expires_at=datetime.utcnow() + timedelta(hours=24)
        )
        db.session.add(verification)
        db.session.commit()
        return True, 'If the email exists and is not verified, a new link has been sent'

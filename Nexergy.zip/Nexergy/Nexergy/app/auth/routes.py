from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
from app.extensions import limiter
from app.auth.service import AuthService
from app.auth.schemas import (
    RegisterSchema, LoginSchema, ChangePasswordSchema,
    ForgotPasswordSchema, ResetPasswordSchema, VerifyEmailSchema
)

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/register', methods=['POST'])
@limiter.limit("5 per hour")
def register():
    schema = RegisterSchema()
    errors = schema.validate(request.json or {})
    if errors:
        return jsonify({'error': 'Validation Error', 'message': errors}), 422

    data = schema.load(request.json)
    result, error = AuthService.register(data['email'], data['first_name'], data['last_name'])

    if error:
        return jsonify({'error': 'Registration Failed', 'message': error}), 409

    return jsonify({
        'message': 'Registration successful. Check your email for verification link and credentials.',
        'user': result['user'].to_dict()
    }), 201


@auth_bp.route('/login', methods=['POST'])
@limiter.limit("10 per minute")
def login():
    schema = LoginSchema()
    errors = schema.validate(request.json or {})
    if errors:
        return jsonify({'error': 'Validation Error', 'message': errors}), 422

    data = schema.load(request.json)
    result, error = AuthService.login(
        data['email'], data['password'],
        ip=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )

    if error:
        return jsonify({'error': 'Authentication Failed', 'message': error}), 401

    return jsonify(result), 200


@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    jwt_data = get_jwt()
    AuthService.logout(jwt_data['jti'], 'access')
    return jsonify({'message': 'Successfully logged out'}), 200


@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    identity = get_jwt_identity()
    result, error = AuthService.refresh_tokens(identity)
    if error:
        return jsonify({'error': 'Refresh Failed', 'message': error}), 401
    return jsonify(result), 200


@auth_bp.route('/verify-email', methods=['POST'])
def verify_email():
    schema = VerifyEmailSchema()
    errors = schema.validate(request.json or {})
    if errors:
        return jsonify({'error': 'Validation Error', 'message': errors}), 422

    data = schema.load(request.json)
    success, message = AuthService.verify_email(data['token'])
    if not success:
        return jsonify({'error': 'Verification Failed', 'message': message}), 400
    return jsonify({'message': message}), 200


@auth_bp.route('/resend-verification', methods=['POST'])
@limiter.limit("3 per hour")
def resend_verification():
    email = (request.json or {}).get('email')
    if not email:
        return jsonify({'error': 'Validation Error', 'message': 'Email is required'}), 422
    success, message = AuthService.resend_verification(email)
    return jsonify({'message': message}), 200


@auth_bp.route('/forgot-password', methods=['POST'])
@limiter.limit("3 per hour")
def forgot_password():
    schema = ForgotPasswordSchema()
    errors = schema.validate(request.json or {})
    if errors:
        return jsonify({'error': 'Validation Error', 'message': errors}), 422

    data = schema.load(request.json)
    success, message = AuthService.forgot_password(data['email'])
    return jsonify({'message': message}), 200


@auth_bp.route('/reset-password', methods=['POST'])
def reset_password():
    schema = ResetPasswordSchema()
    errors = schema.validate(request.json or {})
    if errors:
        return jsonify({'error': 'Validation Error', 'message': errors}), 422

    data = schema.load(request.json)
    success, message = AuthService.reset_password(data['token'], data['new_password'])
    if not success:
        return jsonify({'error': 'Reset Failed', 'message': message}), 400
    return jsonify({'message': message}), 200


@auth_bp.route('/change-password', methods=['POST'])
@jwt_required()
def change_password():
    schema = ChangePasswordSchema()
    errors = schema.validate(request.json or {})
    if errors:
        return jsonify({'error': 'Validation Error', 'message': errors}), 422

    data = schema.load(request.json)
    user_id = get_jwt_identity()
    success, message = AuthService.change_password(int(user_id), data['current_password'], data['new_password'])
    if not success:
        return jsonify({'error': 'Change Failed', 'message': message}), 400
    return jsonify({'message': message}), 200


@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def get_me():
    from app.models.user import User
    user_id = get_jwt_identity()
    user = User.query.get(int(user_id))
    if not user:
        return jsonify({'error': 'Not Found', 'message': 'User not found'}), 404

    user_data = user.to_dict()
    if user.profile:
        user_data['profile'] = user.profile.to_dict()
    return jsonify(user_data), 200

from app.core.base_repository import BaseRepository
from app.models import User, EmailVerification, PasswordReset
from sqlalchemy import and_, desc


class AuthRepository(BaseRepository):
    """Repository para operaciones de autenticación"""

    def get_user_by_email(self, email: str):
        """Obtiene usuario por email"""
        return User.query.filter_by(email=email).first()

    def create_user(self, email: str, password_hash: str):
        """Crea un nuevo usuario"""
        user = User(email=email, password_hash=password_hash)
        self.db.session.add(user)
        self.db.session.commit()
        return user

    def verify_user(self, user_id: int):
        """Marca usuario como verificado"""
        user = User.query.get(user_id)
        if user:
            user.is_verified = True
            self.db.session.commit()
        return user

    def create_email_verification_token(self, user_id: int, token: str, expires_at):
        """Crea token de verificación de email"""
        ev = EmailVerification(user_id=user_id, token=token, expires_at=expires_at)
        self.db.session.add(ev)
        self.db.session.commit()
        return ev

    def get_email_verification_by_token(self, token: str):
        """Obtiene token de verificación por token"""
        return EmailVerification.query.filter_by(token=token).first()

    def create_password_reset_token(self, user_id: int, token: str, expires_at):
        """Crea token de reset de contraseña"""
        pr = PasswordReset(user_id=user_id, token=token, expires_at=expires_at)
        self.db.session.add(pr)
        self.db.session.commit()
        return pr

    def get_password_reset_by_token(self, token: str):
        """Obtiene token de reset por token"""
        return PasswordReset.query.filter_by(token=token).first()

    def update_user_password(self, user_id: int, password_hash: str, force_change: bool = False):
        """Actualiza contraseña del usuario"""
        user = User.query.get(user_id)
        if user:
            user.password_hash = password_hash
            user.force_password_change = force_change
            self.db.session.commit()
        return user

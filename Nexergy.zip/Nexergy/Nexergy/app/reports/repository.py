"""Repository para operaciones de reportes"""
from app.core.base_repository import BaseRepository
from app.models import ActivityLog
from sqlalchemy import desc


class ReportsRepository(BaseRepository):
    """Repository para reportes"""

    def get_user_reports_data(self, user_id: int, report_type: str):
        """Obtiene datos para generar reporte"""
        from app.models import User, Home, EnergyReading, Device
        from datetime import datetime, timedelta
        
        if report_type == 'energy':
            homes = Home.query.filter_by(user_id=user_id).all()
            readings = []
            for home in homes:
                readings.extend(EnergyReading.query.filter_by(home_id=home.id).all())
            return readings
        
        elif report_type == 'devices':
            homes = Home.query.filter_by(user_id=user_id).all()
            devices = []
            for home in homes:
                devices.extend(Device.query.filter_by(home_id=home.id).all())
            return devices
        
        elif report_type == 'activity':
            return ActivityLog.query.filter_by(user_id=user_id).order_by(
                desc(ActivityLog.timestamp)
            ).limit(1000).all()
        
        return []

    def get_activity_logs(self, user_id: int, limit: int = 500):
        """Obtiene logs de actividad"""
        return ActivityLog.query.filter_by(user_id=user_id).order_by(
            desc(ActivityLog.timestamp)
        ).limit(limit).all()

"""Servicio para generar reportes"""
from app.core.base_service import BaseService
from app.reports.repository import ReportsRepository
from datetime import datetime


class ReportsService(BaseService):
    """Servicio para reportes"""

    def __init__(self):
        super().__init__()
        self.repository = ReportsRepository()

    def generate_report(self, user_id: int, report_type: str, format: str = 'pdf'):
        """Genera reporte según tipo y formato"""
        data = self.repository.get_user_reports_data(user_id, report_type)
        
        report = {
            'id': datetime.utcnow().timestamp(),
            'user_id': user_id,
            'type': report_type,
            'format': format,
            'created_at': datetime.utcnow(),
            'data_count': len(data) if data else 0
        }
        
        return report

    def generate_energy_report(self, user_id: int, start_date=None, end_date=None):
        """Genera reporte de energía"""
        return self.generate_report(user_id, 'energy', 'pdf')

    def generate_devices_report(self, user_id: int):
        """Genera reporte de dispositivos"""
        return self.generate_report(user_id, 'devices', 'pdf')

    def generate_activity_report(self, user_id: int):
        """Genera reporte de actividad"""
        return self.generate_report(user_id, 'activity', 'pdf')

    def export_to_csv(self, user_id: int, report_type: str):
        """Exporta reporte a CSV"""
        data = self.repository.get_user_reports_data(user_id, report_type)
        return {
            'format': 'csv',
            'data': data,
            'row_count': len(data) if data else 0
        }

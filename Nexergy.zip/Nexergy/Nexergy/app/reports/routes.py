"""Endpoints para reportes"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.core.decorators import handle_exceptions
from app.reports.service import ReportsService
from app.reports.pdf_generator import ReportPDFGenerator

reports_bp = Blueprint('reports', __name__)
service = ReportsService()


@reports_bp.route('/generate', methods=['POST'])
@jwt_required()
@handle_exceptions
def generate_report():
    """Genera nuevo reporte"""
    user_id = get_jwt_identity()
    data = request.json
    report_type = data.get('type', 'energy')
    format = data.get('format', 'pdf')
    
    if report_type not in ['energy', 'devices', 'activity']:
        return jsonify({'error': 'Invalid report type'}), 400
    
    report = service.generate_report(user_id, report_type, format)
    
    return jsonify({
        'success': True,
        'report': report
    }), 201


@reports_bp.route('/reports', methods=['GET'])
@jwt_required()
@handle_exceptions
def list_reports():
    """Lista reportes disponibles (simulado)"""
    user_id = get_jwt_identity()
    
    return jsonify({
        'success': True,
        'reports': [
            {
                'id': 1,
                'type': 'energy',
                'created_at': '2025-01-15T10:30:00',
                'format': 'pdf'
            },
            {
                'id': 2,
                'type': 'devices',
                'created_at': '2025-01-14T14:20:00',
                'format': 'pdf'
            }
        ]
    }), 200


@reports_bp.route('/export/<report_type>', methods=['GET'])
@jwt_required()
@handle_exceptions
def export_report(report_type):
    """Exporta reporte en formato especificado"""
    user_id = get_jwt_identity()
    format = request.args.get('format', 'pdf')
    
    if report_type == 'energy':
        report = service.generate_energy_report(user_id)
    elif report_type == 'devices':
        report = service.generate_devices_report(user_id)
    elif report_type == 'activity':
        report = service.generate_activity_report(user_id)
    else:
        return jsonify({'error': 'Invalid report type'}), 400
    
    pdf_info = ReportPDFGenerator.generate_energy_report(user_id, {})
    
    return jsonify({
        'success': True,
        'report': report,
        'download': pdf_info
    }), 200

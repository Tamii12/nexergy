"""Schemas para gamificación"""
from marshmallow import Schema, fields


class AchievementSchema(Schema):
    id = fields.Integer()
    key = fields.String()
    name = fields.String()
    description = fields.String()
    icon = fields.String()
    criteria_json = fields.Dict()


class UserAchievementSchema(Schema):
    user_id = fields.Integer()
    achievement_id = fields.Integer()
    unlocked_at = fields.DateTime()
    progress = fields.Decimal(places=2)


class LeaderboardSchema(Schema):
    rank = fields.Integer()
    user_id = fields.Integer()
    username = fields.String()
    achievements_count = fields.Integer()
    total_progress = fields.Decimal(places=2)

"""Repository para gamificación"""
from app.core.base_repository import BaseRepository
from app.models import Achievement, UserAchievement, User
from sqlalchemy import func, desc


class GamificationRepository(BaseRepository):
    """Repository para operaciones de gamificación"""

    def get_achievements(self):
        """Obtiene todos los logros disponibles"""
        return Achievement.query.all()

    def get_achievement_by_key(self, key: str):
        """Obtiene logro por clave"""
        return Achievement.query.filter_by(key=key).first()

    def get_user_achievements(self, user_id: int):
        """Obtiene logros desbloqueados del usuario"""
        return UserAchievement.query.filter_by(user_id=user_id).all()

    def unlock_achievement(self, user_id: int, achievement_id: int, progress: float = 100.0):
        """Desbloquea un logro para el usuario"""
        existing = UserAchievement.query.filter_by(
            user_id=user_id,
            achievement_id=achievement_id
        ).first()
        
        if not existing:
            ua = UserAchievement(
                user_id=user_id,
                achievement_id=achievement_id,
                progress=progress
            )
            self.db.session.add(ua)
            self.db.session.commit()
            return ua
        return existing

    def update_achievement_progress(self, user_id: int, achievement_id: int, progress: float):
        """Actualiza progreso de un logro"""
        ua = UserAchievement.query.filter_by(
            user_id=user_id,
            achievement_id=achievement_id
        ).first()
        
        if ua:
            ua.progress = min(progress, 100.0)
            self.db.session.commit()
        return ua

    def get_leaderboard(self, limit: int = 10):
        """Obtiene tabla de clasificación"""
        from sqlalchemy import and_
        query = self.db.session.query(
            User.id.label('user_id'),
            User.email,
            func.count(UserAchievement.achievement_id).label('achievements_count'),
            func.avg(UserAchievement.progress).label('avg_progress')
        ).outerjoin(UserAchievement).group_by(User.id).order_by(
            desc(func.count(UserAchievement.achievement_id))
        ).limit(limit)
        
        return query.all()

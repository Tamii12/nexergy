"""Motor de evaluación de logros"""
from app.models import Device, Home, SaveGoal, AlertRule, Recommendation, EnergyReading, User
from app.gamification.constants import ACHIEVEMENTS
from datetime import datetime, timedelta


class GamificationEngine:
    """Motor para evaluar logros basado en criterios"""

    @staticmethod
    def evaluate_achievements(user_id: int, repository):
        """Evalúa todos los logros posibles para un usuario"""
        unlocked = []
        
        # Evaluar logros basados en criterios
        metrics = GamificationEngine.get_user_metrics(user_id)
        
        for achievement_key, achievement_data in ACHIEVEMENTS.items():
            criteria = achievement_data.get('criteria', {})
            
            # Verificar si cumple criterios
            if GamificationEngine.check_criteria(criteria, metrics):
                # Buscar el achievement en BD para obtener su ID
                from app.models import Achievement
                achievement = Achievement.query.filter_by(key=achievement_key).first()
                
                if achievement:
                    # Desbloquear logro
                    unlocked_achievement = repository.unlock_achievement(
                        user_id,
                        achievement.id,
                        100.0
                    )
                    unlocked.append(unlocked_achievement)
        
        return unlocked

    @staticmethod
    def get_user_metrics(user_id: int):
        """Obtiene métricas del usuario para evaluación"""
        from datetime import datetime, date
        
        homes = Home.query.filter_by(user_id=user_id).all()
        home_ids = [h.id for h in homes]
        
        # Contar dispositivos
        devices = Device.query.filter(Device.home_id.in_(home_ids)).all() if home_ids else []
        
        # Contar metas
        goals = SaveGoal.query.filter_by(user_id=user_id).all()
        
        # Contar reglas de alerta
        alert_rules = AlertRule.query.filter_by(user_id=user_id).all()
        
        # Contar recomendaciones aplicadas
        recommendations = Recommendation.query.filter(
            Recommendation.user_id == user_id,
            Recommendation.is_applied == True
        ).all()
        
        # Calcular consumo actual vs anterior
        today = date.today()
        yesterday = today - timedelta(days=1)
        last_month = date(today.year, today.month - 1 if today.month > 1 else 12,
                         today.day if today.day <= 28 else 28)
        
        current_month_readings = EnergyReading.query.filter(
            EnergyReading.home_id.in_(home_ids) if home_ids else False
        ).filter(
            EnergyReading.timestamp >= datetime.combine(date(today.year, today.month, 1), datetime.min.time())
        ).all() if home_ids else []
        
        previous_month_readings = EnergyReading.query.filter(
            EnergyReading.home_id.in_(home_ids) if home_ids else False
        ).filter(
            EnergyReading.timestamp >= datetime.combine(last_month, datetime.min.time()),
            EnergyReading.timestamp < datetime.combine(date(today.year, today.month, 1), datetime.min.time())
        ).all() if home_ids else []
        
        current_kwh = sum(r.kwh for r in current_month_readings) if current_month_readings else 0
        previous_kwh = sum(r.kwh for r in previous_month_readings) if previous_month_readings else 0
        
        reduction_percent = 0
        if previous_kwh > 0:
            reduction_percent = ((previous_kwh - current_kwh) / previous_kwh) * 100
        
        # Calcular días activos
        user = User.query.get(user_id)
        days_active = (datetime.utcnow().date() - user.created_at.date()).days if user else 0
        
        return {
            'devices_count': len(devices),
            'goals_count': len(goals),
            'alert_rules_count': len(alert_rules),
            'recommendations_applied': len(recommendations),
            'consumption_reduction_percent': max(0, reduction_percent),
            'days_active': days_active
        }

    @staticmethod
    def check_criteria(criteria: dict, metrics: dict):
        """Verifica si las métricas cumplen los criterios"""
        for key, value in criteria.items():
            if key not in metrics:
                return False
            if metrics[key] < value:
                return False
        return True

    @staticmethod
    def check_milestone(user_id: int, milestone: str, repository):
        """Verifica un hito específico"""
        metrics = GamificationEngine.get_user_metrics(user_id)
        
        milestones = {
            'first_device': metrics['devices_count'] >= 1,
            'five_devices': metrics['devices_count'] >= 5,
            'energy_reduction_20': metrics['consumption_reduction_percent'] >= 20,
            'energy_reduction_50': metrics['consumption_reduction_percent'] >= 50,
            'three_goals': metrics['goals_count'] >= 3,
            'five_rules': metrics['alert_rules_count'] >= 5
        }
        
        return milestones.get(milestone, False)

"""Servicio de gamificación"""
from app.core.base_service import BaseService
from app.gamification.repository import GamificationRepository
from app.gamification.engine import GamificationEngine


class GamificationService(BaseService):
    """Servicio para operaciones de gamificación"""

    def __init__(self):
        super().__init__()
        self.repository = GamificationRepository()
        self.engine = GamificationEngine()

    def get_user_achievements(self, user_id: int):
        """Obtiene logros desbloqueados del usuario"""
        return self.repository.get_user_achievements(user_id)

    def evaluate_user_achievements(self, user_id: int):
        """Evalúa y desbloquea logros para el usuario"""
        return self.engine.evaluate_achievements(user_id, self.repository)

    def get_achievement_progress(self, user_id: int):
        """Obtiene progreso general de logros"""
        achievements = self.get_user_achievements(user_id)
        all_achievements = self.repository.get_achievements()
        
        unlocked_count = len(achievements)
        total_count = len(all_achievements)
        avg_progress = sum(a.progress for a in achievements) / len(achievements) if achievements else 0
        
        return {
            'unlocked': unlocked_count,
            'total': total_count,
            'percentage': (unlocked_count / total_count * 100) if total_count > 0 else 0,
            'average_progress': avg_progress
        }

    def get_leaderboard(self, limit: int = 10):
        """Obtiene tabla de clasificación de logros"""
        return self.repository.get_leaderboard(limit)

    def check_milestone(self, user_id: int, milestone: str):
        """Verifica si el usuario alcanzó un hito"""
        return self.engine.check_milestone(user_id, milestone, self.repository)

    def get_user_metrics(self, user_id: int):
        """Obtiene métricas actuales del usuario"""
        return self.engine.get_user_metrics(user_id)

"""Endpoints para gamificación"""
from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.core.decorators import handle_exceptions
from app.gamification.service import GamificationService
from app.gamification.schemas import AchievementSchema, UserAchievementSchema, LeaderboardSchema

gamification_bp = Blueprint('gamification', __name__)
service = GamificationService()


@gamification_bp.route('/achievements', methods=['GET'])
@jwt_required()
@handle_exceptions
def get_achievements():
    """Obtiene logros desbloqueados del usuario"""
    user_id = get_jwt_identity()
    achievements = service.get_user_achievements(user_id)
    
    schema = UserAchievementSchema(many=True)
    return jsonify({
        'success': True,
        'achievements': schema.dump(achievements)
    }), 200


@gamification_bp.route('/progress', methods=['GET'])
@jwt_required()
@handle_exceptions
def get_progress():
    """Obtiene progreso general de logros"""
    user_id = get_jwt_identity()
    progress = service.get_achievement_progress(user_id)
    
    return jsonify({
        'success': True,
        'progress': progress
    }), 200


@gamification_bp.route('/evaluate', methods=['POST'])
@jwt_required()
@handle_exceptions
def evaluate_achievements():
    """Evalúa y desbloquea nuevos logros"""
    user_id = get_jwt_identity()
    unlocked = service.evaluate_user_achievements(user_id)
    
    schema = UserAchievementSchema(many=True)
    return jsonify({
        'success': True,
        'newly_unlocked': schema.dump(unlocked),
        'count': len(unlocked)
    }), 200


@gamification_bp.route('/leaderboard', methods=['GET'])
@handle_exceptions
def get_leaderboard():
    """Obtiene tabla de clasificación de logros"""
    leaderboard = service.get_leaderboard(10)
    
    result = []
    for rank, entry in enumerate(leaderboard, 1):
        result.append({
            'rank': rank,
            'user_id': entry.user_id,
            'email': entry.email,
            'achievements_count': entry.achievements_count,
            'average_progress': float(entry.avg_progress or 0)
        })
    
    return jsonify({
        'success': True,
        'leaderboard': result
    }), 200


@gamification_bp.route('/metrics', methods=['GET'])
@jwt_required()
@handle_exceptions
def get_metrics():
    """Obtiene métricas del usuario para cálculo de logros"""
    user_id = get_jwt_identity()
    metrics = service.get_user_metrics(user_id)
    
    return jsonify({
        'success': True,
        'metrics': metrics
    }), 200

"""Constants para gamificación"""

# Tipos de logros
ACHIEVEMENT_TYPE_ENERGY_SAVER = 'energy_saver'
ACHIEVEMENT_TYPE_SMART_USER = 'smart_user'
ACHIEVEMENT_TYPE_COLLECTOR = 'collector'
ACHIEVEMENT_TYPE_EXPLORER = 'explorer'
ACHIEVEMENT_TYPE_GUARDIAN = 'guardian'

ACHIEVEMENT_TYPES = [
    ACHIEVEMENT_TYPE_ENERGY_SAVER,
    ACHIEVEMENT_TYPE_SMART_USER,
    ACHIEVEMENT_TYPE_COLLECTOR,
    ACHIEVEMENT_TYPE_EXPLORER,
    ACHIEVEMENT_TYPE_GUARDIAN
]

# Definición de logros con criterios
ACHIEVEMENTS = {
    'first_device': {
        'name': 'Primer Dispositivo',
        'description': 'Registra tu primer dispositivo IoT',
        'icon': 'device',
        'type': ACHIEVEMENT_TYPE_COLLECTOR,
        'criteria': {'devices_count': 1}
    },
    'energy_aware': {
        'name': 'Consciente de Energía',
        'description': 'Reduce 20% tu consumo mensual',
        'icon': 'lightning',
        'type': ACHIEVEMENT_TYPE_ENERGY_SAVER,
        'criteria': {'consumption_reduction_percent': 20}
    },
    'smart_home': {
        'name': 'Casa Inteligente',
        'description': 'Configura 5 dispositivos',
        'icon': 'home',
        'type': ACHIEVEMENT_TYPE_SMART_USER,
        'criteria': {'devices_count': 5}
    },
    'power_user': {
        'name': 'Usuario Avanzado',
        'description': 'Crea 3 metas de ahorro',
        'icon': 'trophy',
        'type': ACHIEVEMENT_TYPE_SMART_USER,
        'criteria': {'goals_count': 3}
    },
    'energy_master': {
        'name': 'Maestro de Energía',
        'description': 'Reduce 50% tu consumo durante un mes',
        'icon': 'star',
        'type': ACHIEVEMENT_TYPE_ENERGY_SAVER,
        'criteria': {'consumption_reduction_percent': 50}
    },
    'early_adopter': {
        'name': 'Adoptador Temprano',
        'description': 'Verifica tu email en los primeros 7 días',
        'icon': 'rocket',
        'type': ACHIEVEMENT_TYPE_EXPLORER,
        'criteria': {'days_active': 7}
    },
    'protector': {
        'name': 'Protector',
        'description': 'Crea 5 reglas de alerta',
        'icon': 'shield',
        'type': ACHIEVEMENT_TYPE_GUARDIAN,
        'criteria': {'alert_rules_count': 5}
    },
    'recommendation_follower': {
        'name': 'Seguidor de Recomendaciones',
        'description': 'Aplica 5 recomendaciones',
        'icon': 'check',
        'type': ACHIEVEMENT_TYPE_SMART_USER,
        'criteria': {'recommendations_applied': 5}
    }
}
